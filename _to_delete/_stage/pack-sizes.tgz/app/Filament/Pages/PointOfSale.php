<?php

namespace App\Filament\Pages;

use App\Enums\DiscountType;
use App\Enums\PaymentMethod;
use App\Models\Product;
use App\Services\InventoryService;
use App\Services\PosService;
use App\Support\SellingOption;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Illuminate\Contracts\Support\Htmlable;
use Illuminate\Support\Collection;
use Livewire\Attributes\Computed;

/**
 * The cashier's terminal.
 *
 * Scan (or type) a code, the item drops into the cart, F2 jumps to cash
 * received, Enter takes the payment. Stock is deducted first-expiring-first
 * the moment the sale is committed.
 */
class PointOfSale extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-shopping-cart';

    protected static ?string $navigationGroup = 'Point of Sale';

    protected static ?string $navigationLabel = 'New sale (POS)';

    protected static ?int $navigationSort = 1;

    protected static string $view = 'filament.pages.point-of-sale';

    /** The code typed or scanned into the search box. */
    public string $scan = '';

    /**
     * Cart lines, keyed "productId:UNIT" so the same product can sit in the
     * cart twice — a full box on one line, three loose tablets on another.
     *
     * @var array<string, array{product_id:int, name:string, generic:?string, unit:string, unit_label:string, unit_multiplier:int, unit_options:array<string, string>, batch:?string, expiry:?string, unit_price:float, quantity:int, discount_percent:float, stock:int}>
     */
    public array $cart = [];

    public string $paymentMethod = 'CASH';

    public string $discountType = 'NONE';

    public float $discountPercent = 0;

    public ?float $amountPaid = null;

    public ?string $customerName = null;

    public ?string $discountIdNumber = null;

    /** Populated when a scan matches more than one product. */
    public array $suggestions = [];

    /** Set after a successful checkout so the receipt can be opened. */
    public ?int $lastSaleId = null;

    public ?string $lastInvoiceNumber = null;

    public function getTitle(): string|Htmlable
    {
        return 'Point of Sale';
    }

    public function getSubheading(): ?string
    {
        $branch = auth()->user()->branch?->name ?? 'No branch assigned';

        return $branch.' · '.now()->format('l, d F Y');
    }

    /* ============================================================ Scanning */

    /**
     * Enter pressed in the scan box: an exact barcode/SKU match goes straight
     * into the cart, anything else shows a short pick-list.
     */
    public function submitScan(): void
    {
        $term = trim($this->scan);

        if ($term === '') {
            return;
        }

        $exact = Product::query()
            ->active()
            ->where(fn ($q) => $q->where('barcode', $term)->orWhere('sku', $term))
            ->first();

        if ($exact) {
            $this->addToCart($exact->id);
            $this->scan = '';
            $this->suggestions = [];

            return;
        }

        $matches = $this->posService()->search($term, $this->branchId());

        if ($matches->count() === 1) {
            $this->addToCart($matches->first()->id);
            $this->scan = '';
            $this->suggestions = [];

            return;
        }

        if ($matches->isEmpty()) {
            Notification::make()
                ->title('No product found')
                ->body("Nothing matches \"{$term}\".")
                ->warning()
                ->send();

            $this->suggestions = [];

            return;
        }

        $this->suggestions = $this->presentSuggestions($matches);
    }

    /** Live pick-list while typing a product name. */
    public function updatedScan(string $value): void
    {
        $value = trim($value);

        if (strlen($value) < 2) {
            $this->suggestions = [];

            return;
        }

        $this->suggestions = $this->presentSuggestions(
            $this->posService()->search($value, $this->branchId())
        );
    }

    protected function presentSuggestions(Collection $products): array
    {
        return $products->map(fn (Product $product): array => [
            'id' => $product->id,
            'name' => $product->name,
            'generic' => $product->medicine?->full_name,
            'price' => (float) $product->selling_price,
            'stock' => (int) ($product->stock_on_hand ?? 0),
            'unit' => $product->unit,
            'stock_label' => $product->formatPieces((int) ($product->stock_on_hand ?? 0)),
        ])->all();
    }

    /* ================================================================ Cart */

    public function addToCart(int $productId, ?string $unit = null): void
    {
        $product = Product::with(['medicine', 'packs'])->find($productId);

        if (! $product) {
            return;
        }

        $sellingUnit = $this->resolveUnit($product, $unit);
        $key = $this->cartKey($productId, $sellingUnit);

        if (isset($this->cart[$key])) {
            $this->increment($key);

            return;
        }

        $available = $this->inventoryService()->availableStock($this->branchId(), $product->id);
        $pieces = $sellingUnit->pieces;

        if ($available < $pieces + $this->piecesReserved($productId)) {
            $this->reportShortStock($product, $available);

            return;
        }

        $nextBatch = $product->batches()
            ->inStock()
            ->where('branch_id', $this->branchId())
            ->fefo()
            ->first();

        $this->cart[$key] = [
            'product_id' => $product->id,
            'name' => $product->name,
            'generic' => $product->medicine?->full_name,
            'unit' => $sellingUnit->key,
            'unit_label' => $sellingUnit->label,
            'unit_multiplier' => $pieces,
            'unit_options' => $product->sellingUnitOptions(),
            'batch' => $nextBatch?->batch_number,
            'expiry' => $nextBatch?->expiration_date?->format('m/Y'),
            'unit_price' => $product->priceFor($sellingUnit->key),
            'quantity' => 1,
            'discount_percent' => 0,
            'stock' => $available,
            'stock_label' => $product->formatPieces($available),
        ];

        $this->cart[$key]['rx'] = (bool) $product->medicine?->requires_prescription;

        $this->scan = '';
        $this->suggestions = [];
    }

    /**
     * Switch a line between the whole pack, a pack tier and a single piece.
     *
     * Quantity carries over, so a line of 2 boxes becomes 2 blisters rather
     * than resetting — but it is clamped to whatever the shelf can cover.
     */
    public function changeUnit(string $key, string $unit): void
    {
        if (! isset($this->cart[$key])) {
            return;
        }

        $line = $this->cart[$key];
        $product = Product::with(['medicine', 'packs'])->find($line['product_id']);

        if (! $product) {
            return;
        }

        $sellingUnit = $this->resolveUnit($product, $unit);
        $newKey = $this->cartKey($line['product_id'], $sellingUnit);
        $pieces = $sellingUnit->pieces;

        $spare = $line['stock'] - $this->piecesReserved($line['product_id'], skipKey: $key);
        $quantity = max(1, min((int) $line['quantity'], intdiv(max(0, $spare), max(1, $pieces))));

        if ($quantity < 1) {
            $this->reportShortStock($product, $line['stock']);

            return;
        }

        unset($this->cart[$key]);

        // Moving onto a unit already in the cart merges the two lines.
        if (isset($this->cart[$newKey])) {
            $this->cart[$newKey]['quantity'] += $quantity;

            return;
        }

        $this->cart[$newKey] = [
            ...$line,
            'unit' => $sellingUnit->key,
            'unit_label' => $sellingUnit->label,
            'unit_multiplier' => $pieces,
            'unit_price' => $product->priceFor($sellingUnit->key),
            'quantity' => $quantity,
        ];
    }

    public function increment(string $key): void
    {
        if (! isset($this->cart[$key])) {
            return;
        }

        $line = $this->cart[$key];

        if ($this->piecesReserved($line['product_id']) + $line['unit_multiplier'] > $line['stock']) {
            $product = Product::find($line['product_id']);

            if ($product) {
                $this->reportShortStock($product, $line['stock']);
            }

            return;
        }

        $this->cart[$key]['quantity']++;
    }

    public function decrement(string $key): void
    {
        if (! isset($this->cart[$key])) {
            return;
        }

        if ($this->cart[$key]['quantity'] <= 1) {
            $this->removeItem($key);

            return;
        }

        $this->cart[$key]['quantity']--;
    }

    public function removeItem(string $key): void
    {
        unset($this->cart[$key]);
    }

    /* ------------------------------------------------------- Cart helpers */

    protected function cartKey(int $productId, SellingOption $unit): string
    {
        return $productId.'@'.$unit->key;
    }

    /** Falls back to the whole pack when a unit is missing or no longer sold. */
    protected function resolveUnit(Product $product, ?string $unit): SellingOption
    {
        return $product->sellingOption($unit);
    }

    /**
     * Pieces of a product already spoken for across every line in the cart.
     *
     * A box on one line and four tablets on another draw on the same shelf, so
     * the stock check has to look at all of them together.
     */
    protected function piecesReserved(int $productId, ?string $skipKey = null): int
    {
        $reserved = 0;

        foreach ($this->cart as $key => $line) {
            if ($key === $skipKey || $line['product_id'] !== $productId) {
                continue;
            }

            $reserved += (int) $line['quantity'] * (int) $line['unit_multiplier'];
        }

        return $reserved;
    }

    protected function reportShortStock(Product $product, int $available): void
    {
        Notification::make()
            ->title('Not enough stock')
            ->body("{$product->name} has {$product->formatPieces($available)} on hand.")
            ->warning()
            ->send();
    }

    public function voidAll(): void
    {
        $this->reset(['cart', 'scan', 'suggestions', 'amountPaid', 'customerName', 'discountIdNumber']);
        $this->discountType = 'NONE';
        $this->discountPercent = 0;
    }

    /* ============================================================== Totals */

    #[Computed]
    public function totals(): array
    {
        if (empty($this->cart)) {
            return [
                'gross' => 0.0, 'line_discount' => 0.0, 'subtotal' => 0.0,
                'discount' => 0.0, 'vat' => 0.0, 'vat_exempt' => false, 'total' => 0.0,
            ];
        }

        return $this->posService()->totals(
            array_values($this->cart),
            DiscountType::from($this->discountType),
            (float) $this->discountPercent,
        );
    }

    #[Computed]
    public function changeDue(): float
    {
        return max(0, round(((float) $this->amountPaid) - $this->totals['total'], 2));
    }

    /* ============================================================ Checkout */

    public function checkout(): void
    {
        if (empty($this->cart)) {
            Notification::make()->title('The cart is empty')->warning()->send();

            return;
        }

        if (! $this->branchId()) {
            Notification::make()
                ->title('No branch assigned')
                ->body('Ask an administrator to assign your account to a branch.')
                ->danger()
                ->send();

            return;
        }

        try {
            $sale = $this->posService()->checkout(
                cart: array_values($this->cart),
                branchId: $this->branchId(),
                amountPaid: (float) ($this->amountPaid ?? $this->totals['total']),
                paymentMethod: PaymentMethod::from($this->paymentMethod),
                discountType: DiscountType::from($this->discountType),
                discountPercent: (float) $this->discountPercent,
                customerName: $this->customerName,
                discountIdNumber: $this->discountIdNumber,
            );

            $this->lastSaleId = $sale->id;
            $this->lastInvoiceNumber = $sale->invoice_number;

            Notification::make()
                ->title("Sale {$sale->invoice_number} completed")
                ->body('Change due: ₱'.number_format((float) $sale->change_amount, 2))
                ->success()
                ->send();

            $this->voidAll();

            // Pops the printable receipt in a new tab.
            $this->dispatch('open-receipt', url: route('receipts.show', $sale));
        } catch (\Throwable $e) {
            Notification::make()
                ->title('Could not complete the sale')
                ->body($e->getMessage())
                ->danger()
                ->persistent()
                ->send();
        }
    }

    /* ============================================================= Helpers */

    public function branchId(): ?int
    {
        return auth()->user()?->branch_id;
    }

    protected function posService(): PosService
    {
        return app(PosService::class);
    }

    protected function inventoryService(): InventoryService
    {
        return app(InventoryService::class);
    }

    public function getPaymentMethods(): array
    {
        return collect(PaymentMethod::cases())
            ->mapWithKeys(fn (PaymentMethod $m) => [$m->value => $m->getLabel()])
            ->all();
    }

    public function getDiscountTypes(): array
    {
        return collect(DiscountType::cases())
            ->mapWithKeys(fn (DiscountType $d) => [$d->value => $d->getLabel()])
            ->all();
    }
}
