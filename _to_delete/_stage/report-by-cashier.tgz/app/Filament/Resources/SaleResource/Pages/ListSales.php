<?php

namespace App\Filament\Resources\SaleResource\Pages;

use App\Filament\Pages\PointOfSale;
use App\Filament\Resources\SaleResource;
use App\Models\User;
use Filament\Actions;
use Filament\Forms;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Database\Eloquent\Builder;

class ListSales extends ListRecords
{
    protected static string $resource = SaleResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('printReport')
                ->label('Print sales report')
                ->icon('heroicon-o-printer')
                ->color('gray')
                ->modalHeading('Print sales report')
                ->modalSubmitActionLabel('Open report')
                ->form([
                    Forms\Components\Select::make('period')
                        ->label('Period')
                        ->options([
                            'daily' => 'Daily',
                            'weekly' => 'Weekly',
                            'monthly' => 'Monthly',
                            'yearly' => 'Yearly',
                        ])
                        ->default('daily')
                        ->required()
                        ->native(false),

                    Forms\Components\DatePicker::make('date')
                        ->label('Any date inside the period')
                        ->helperText('The report covers the day, week, month or year containing this date.')
                        ->default(now())
                        ->maxDate(now())
                        ->required(),

                    Forms\Components\Select::make('cashier')
                        ->label('Cashier')
                        ->placeholder('All cashiers')
                        ->options(fn (): array => static::cashierOptions())
                        ->searchable()
                        ->native(false)
                        ->helperText('Leave blank to cover everyone.')
                        // A cashier only ever gets their own figures, so there
                        // is nothing for them to choose between.
                        ->visible(fn (): bool => auth()->user()?->isManagement() ?? false),
                ])
                ->action(fn (array $data) => redirect()->route('sales.report', array_filter([
                    'period' => $data['period'],
                    'date' => $data['date'],
                    'cashier' => $data['cashier'] ?? null,
                ]))),

            Actions\Action::make('newSale')
                ->label('New sale')
                ->icon('heroicon-o-shopping-cart')
                ->url(fn (): string => PointOfSale::getUrl()),
        ];
    }

    /**
     * Who this user may run a report on, name => id.
     *
     * Everyone active in the branches they can see, not just people who have
     * rung something up — a report showing a cashier sold nothing all week is
     * an answer worth being able to ask for.
     *
     * @return array<int, string>
     */
    protected static function cashierOptions(): array
    {
        $user = auth()->user();

        return User::query()
            ->where('is_active', true)
            ->when(
                ! $user?->seesAllBranches(),
                fn (Builder $query) => $query->where('branch_id', $user?->branch_id)
            )
            ->orderBy('name')
            ->pluck('name', 'id')
            ->all();
    }
}
