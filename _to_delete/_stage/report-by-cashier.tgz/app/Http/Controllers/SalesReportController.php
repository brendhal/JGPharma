<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use App\Models\User;
use Carbon\CarbonImmutable;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

/**
 * A printable sales summary for a day, week, month or year.
 *
 * Cashiers get their own transactions only; management sees every sale their
 * branch scope allows, and may narrow the report to one cashier.
 */
class SalesReportController extends Controller
{
    /** @var array<int, string> */
    private const PERIODS = ['daily', 'weekly', 'monthly', 'yearly'];

    /**
     * Whose sales this report covers, or null for everyone in scope.
     *
     * A cashier is always pinned to themselves — the request cannot argue
     * otherwise. Management may name anyone, but only within the branches
     * they can already see, so a branch manager asking for another store's
     * cashier gets a 404 rather than a quietly empty page.
     */
    private function resolveCashier(Request $request, User $user): ?User
    {
        if (! $user->isManagement()) {
            return $user;
        }

        $id = $request->integer('cashier');

        if ($id < 1) {
            return null;
        }

        $cashier = User::query()
            ->when(
                ! $user->seesAllBranches(),
                fn ($query) => $query->where('branch_id', $user->branch_id)
            )
            ->find($id);

        abort_if($cashier === null, 404);

        return $cashier;
    }

    public function __invoke(Request $request): View
    {
        $period = $request->string('period')->lower()->toString();

        if (! in_array($period, self::PERIODS, true)) {
            $period = 'daily';
        }

        $anchor = rescue(
            fn (): CarbonImmutable => CarbonImmutable::parse($request->string('date')->toString()),
            CarbonImmutable::now(),
            report: false,
        );

        [$from, $to, $heading] = match ($period) {
            'weekly' => [
                $anchor->startOfWeek(),
                $anchor->endOfWeek(),
                'Week of '.$anchor->startOfWeek()->format('d M Y'),
            ],
            'monthly' => [
                $anchor->startOfMonth(),
                $anchor->endOfMonth(),
                $anchor->format('F Y'),
            ],
            'yearly' => [
                $anchor->startOfYear(),
                $anchor->endOfYear(),
                $anchor->format('Y'),
            ],
            default => [
                $anchor->startOfDay(),
                $anchor->endOfDay(),
                $anchor->format('l, d F Y'),
            ],
        };

        $user = $request->user();
        $cashier = $this->resolveCashier($request, $user);

        $sales = Sale::query()
            ->completed()
            ->with(['cashier', 'branch', 'items.product.medicine'])
            ->withCount('items')
            ->withSum('items as units_sold', 'quantity')
            ->when($cashier, fn ($query) => $query->where('user_id', $cashier->id))
            ->whereBetween('sale_date', [$from, $to])
            ->orderBy('sale_date')
            ->get();

        return view('reports.sales', [
            'sales' => $sales,
            'period' => $period,
            'heading' => $heading,
            'from' => $from,
            'to' => $to,
            'user' => $user,
            'cashier' => $cashier,
            'scopedToSelf' => ! $user->isManagement(),
            'store' => config('pos.store'),
            'totals' => [
                'gross' => (float) $sales->sum(fn (Sale $sale) => (float) $sale->subtotal),
                'discount' => (float) $sales->sum(fn (Sale $sale) => (float) $sale->discount),
                'vat' => (float) $sales->sum(fn (Sale $sale) => (float) $sale->vat_amount),
                'net' => (float) $sales->sum(fn (Sale $sale) => (float) $sale->total_amount),
                'units' => (int) $sales->sum('units_sold'),
                'transactions' => $sales->count(),
            ],
            'byPaymentMethod' => $sales
                ->groupBy(fn (Sale $sale) => $sale->payment_method?->getLabel() ?? '—')
                ->map(fn ($group) => [
                    'count' => $group->count(),
                    'total' => (float) $group->sum(fn (Sale $sale) => (float) $sale->total_amount),
                ])
                ->sortKeys(),
            'byDay' => $sales
                ->groupBy(fn (Sale $sale) => $sale->sale_date->format('Y-m-d'))
                ->map(fn ($group) => [
                    'count' => $group->count(),
                    'total' => (float) $group->sum(fn (Sale $sale) => (float) $sale->total_amount),
                ])
                ->sortKeys(),
        ]);
    }
}
