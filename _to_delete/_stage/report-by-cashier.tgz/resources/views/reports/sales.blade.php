@php
    use App\Support\Money;

    // One cashier's report, whether they asked for it themselves or a manager
    // picked them. Either way the Cashier column would repeat one name.
    $singleCashier = $cashier !== null;
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sales report — {{ $heading }}@if ($cashier) — {{ $cashier->name }}@endif</title>
    <style>
        :root { --ink: #111827; --muted: #6b7280; --line: #e5e7eb; }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 24px;
            background: #f3f4f6;
            color: var(--ink);
            font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
            font-size: 13px;
        }

        .page {
            max-width: 900px;
            margin: 0 auto;
            background: #fff;
            padding: 32px;
            border-radius: 8px;
        }

        .toolbar {
            max-width: 900px;
            margin: 0 auto 16px;
            display: flex;
            gap: 8px;
            justify-content: flex-end;
        }

        .btn {
            padding: 8px 16px;
            border: 1px solid var(--ink);
            border-radius: 6px;
            background: var(--ink);
            color: #fff;
            font: inherit;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .btn-ghost { background: #fff; color: var(--ink); border-color: var(--line); }

        header { border-bottom: 2px solid var(--ink); padding-bottom: 12px; margin-bottom: 20px; }
        header h1 { margin: 0 0 2px; font-size: 20px; }
        header .sub { color: var(--muted); font-size: 12px; }
        header .store { font-size: 12px; color: var(--muted); margin-bottom: 8px; }

        .cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-bottom: 24px;
        }
        .card {
            border: 1px solid var(--line);
            border-radius: 6px;
            padding: 12px;
        }
        .card .k { font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em; color: var(--muted); }
        .card .v { font-size: 18px; font-weight: 700; margin-top: 4px; font-variant-numeric: tabular-nums; }

        h2 { font-size: 13px; text-transform: uppercase; letter-spacing: 0.05em; color: var(--muted); margin: 24px 0 8px; }

        table { width: 100%; border-collapse: collapse; }
        th {
            text-align: left;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: var(--muted);
            border-bottom: 1px solid var(--line);
            padding: 6px 8px;
        }
        td { padding: 6px 8px; border-bottom: 1px solid #f3f4f6; }
        tfoot td { border-top: 2px solid var(--ink); border-bottom: 0; font-weight: 700; padding-top: 8px; }
        .num { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
        .muted { color: var(--muted); }
        .empty { padding: 32px; text-align: center; color: var(--muted); }

        .split { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }

        tr.txn td { border-bottom: 0; padding-bottom: 2px; }
        tr.lines td { padding: 0 8px 8px 8px; border-bottom: 1px solid #f3f4f6; }
        ul.items { list-style: none; margin: 0; padding: 0 0 0 16px; }
        ul.items li {
            display: flex;
            gap: 8px;
            font-size: 11.5px;
            color: #4b5563;
            padding: 1px 0;
        }
        ul.items li .q { min-width: 34px; font-variant-numeric: tabular-nums; }
        ul.items li .n { flex: 1; }
        ul.items li .a { font-variant-numeric: tabular-nums; text-align: right; min-width: 64px; }
        ul.items li .lot { color: #9ca3af; }

        footer { margin-top: 32px; padding-top: 12px; border-top: 1px solid var(--line); font-size: 11px; color: var(--muted); }

        @media print {
            body { padding: 0; background: #fff; }
            .toolbar { display: none; }
            .page { max-width: none; padding: 0; border-radius: 0; }
            tr { break-inside: avoid; }
            tr.txn { break-after: avoid; }
        }

        @page { margin: 14mm; }
    </style>
</head>
<body>
    <div class="toolbar">
        <a href="javascript:history.back()" class="btn btn-ghost">Back</a>
        <button type="button" class="btn" onclick="window.print()">Print</button>
    </div>

    <div class="page">
        <header>
            <div class="store">
                {{ $store['name'] ?? config('app.name') }}
                @if (! empty($store['tin'])) &middot; TIN {{ $store['tin'] }} @endif
            </div>
            <h1>{{ ucfirst($period) }} sales report</h1>
            <div class="sub">
                {{ $heading }}
                &middot; {{ $from->format('d M Y') }} to {{ $to->format('d M Y') }}
                @if ($singleCashier)
                    &middot; {{ $cashier->name }}
                @else
                    &middot; All cashiers
                @endif
                &middot; {{ $user->branch?->name ?? 'All branches' }}
            </div>
        </header>

        <div class="cards">
            <div class="card">
                <div class="k">Transactions</div>
                <div class="v">{{ number_format($totals['transactions']) }}</div>
            </div>
            <div class="card">
                <div class="k">Units sold</div>
                <div class="v">{{ number_format($totals['units']) }}</div>
            </div>
            <div class="card">
                <div class="k">Discounts</div>
                <div class="v">{{ Money::format($totals['discount']) }}</div>
            </div>
            <div class="card">
                <div class="k">Net sales</div>
                <div class="v">{{ Money::format($totals['net']) }}</div>
            </div>
        </div>

        @if ($sales->isEmpty())
            <div class="empty">No completed sales in this period.</div>
        @else
            <div class="split">
                <div>
                    <h2>By payment method</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Method</th>
                                <th class="num">Txns</th>
                                <th class="num">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($byPaymentMethod as $method => $row)
                                <tr>
                                    <td>{{ $method }}</td>
                                    <td class="num">{{ $row['count'] }}</td>
                                    <td class="num">{{ Money::plain($row['total']) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <div>
                    <h2>By day</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th class="num">Txns</th>
                                <th class="num">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($byDay as $day => $row)
                                <tr>
                                    <td>{{ \Illuminate\Support\Carbon::parse($day)->format('D, d M Y') }}</td>
                                    <td class="num">{{ $row['count'] }}</td>
                                    <td class="num">{{ Money::plain($row['total']) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>

            <h2>Transactions</h2>
            <table>
                <thead>
                    <tr>
                        <th>Invoice</th>
                        <th>Date &amp; time</th>
                        @unless ($singleCashier)
                            <th>Cashier</th>
                        @endunless
                        <th class="num">Items</th>
                        <th class="num">Subtotal</th>
                        <th class="num">Discount</th>
                        <th class="num">VAT</th>
                        <th class="num">Total</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($sales as $sale)
                        <tr class="txn">
                            <td>{{ $sale->invoice_number }}</td>
                            <td class="muted">{{ $sale->sale_date->format('d M Y h:i A') }}</td>
                            @unless ($singleCashier)
                                <td class="muted">{{ $sale->cashier?->name ?? '—' }}</td>
                            @endunless
                            <td class="num">{{ $sale->items_count }}</td>
                            <td class="num">{{ Money::plain($sale->subtotal) }}</td>
                            <td class="num">{{ Money::plain($sale->discount) }}</td>
                            <td class="num">{{ Money::plain($sale->vat_amount) }}</td>
                            <td class="num">{{ Money::plain($sale->total_amount) }}</td>
                        </tr>
                        <tr class="lines">
                            <td colspan="{{ $singleCashier ? 7 : 8 }}">
                                <ul class="items">
                                    @foreach ($sale->items as $item)
                                        <li>
                                            <span class="q">{{ $item->quantity }}&times;</span> <span class="q">{{ $item->unit_label }}</span>
                                            <span class="n">
                                                {{ $item->product?->name ?? 'Item' }}
                                                @if ($item->product?->medicine?->strength)
                                                    <span class="lot">{{ $item->product->medicine->strength }}</span>
                                                @endif
                                                <span class="lot">&#64; {{ Money::plain($item->unit_price) }}</span>
                                            </span>
                                            <span class="a">{{ Money::plain($item->subtotal) }}</span>
                                        </li>
                                    @endforeach
                                </ul>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="{{ $singleCashier ? 3 : 4 }}">Total</td>
                        <td class="num">{{ Money::plain($totals['gross']) }}</td>
                        <td class="num">{{ Money::plain($totals['discount']) }}</td>
                        <td class="num">{{ Money::plain($totals['vat']) }}</td>
                        <td class="num">{{ Money::plain($totals['net']) }}</td>
                    </tr>
                </tfoot>
            </table>
        @endif

        <footer>
            Generated {{ now()->format('d M Y h:i A') }} by {{ $user->name }}
            @if ($scopedToSelf)
                &middot; Covers this account's own transactions only.
            @elseif ($singleCashier)
                &middot; Covers {{ $cashier->name }}'s transactions only.
            @endif
        </footer>
    </div>
</body>
</html>
