<?php

namespace App\Filament\Resources\DisposalResource\Pages;

use App\Filament\Resources\DisposalResource;
use Filament\Actions;
use Filament\Forms;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Contracts\Support\Htmlable;

class ListDisposals extends ListRecords
{
    protected static string $resource = DisposalResource::class;

    public function getHeading(): string|Htmlable
    {
        return 'Disposals';
    }

    public function getSubheading(): ?string
    {
        return 'Expired and damaged stock written off, and what it cost.';
    }

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('printReport')
                ->label('Print disposal report')
                ->icon('heroicon-o-printer')
                ->color('gray')
                ->modalHeading('Print disposal report')
                ->modalSubmitActionLabel('Open report')
                ->form([
                    Forms\Components\Select::make('period')
                        ->label('Period')
                        ->options([
                            'daily' => 'Daily',
                            'weekly' => 'Weekly',
                            'monthly' => 'Monthly',
                            'yearly' => 'Yearly',
                        ])
                        ->default('monthly')
                        ->required()
                        ->native(false),

                    Forms\Components\DatePicker::make('date')
                        ->label('Any date inside the period')
                        ->helperText('The report covers the day, week, month or year containing this date.')
                        ->default(now())
                        ->maxDate(now())
                        ->required(),

                    Forms\Components\Select::make('reason')
                        ->label('Reason')
                        ->placeholder('Expired and damaged')
                        ->options([
                            'EXPIRED' => 'Expired only',
                            'DAMAGED' => 'Damaged only',
                        ])
                        ->native(false)
                        ->helperText('Leave blank to cover both, subtotalled separately.'),
                ])
                ->action(fn (array $data) => redirect()->route('disposals.report', array_filter([
                    'period' => $data['period'],
                    'date' => $data['date'],
                    'reason' => $data['reason'] ?? null,
                ]))),
        ];
    }
}
