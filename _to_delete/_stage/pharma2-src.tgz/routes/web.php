<?php

use App\Http\Controllers\LabelController;
use App\Http\Controllers\ReceiptController;
use App\Http\Controllers\SalesReportController;
use Illuminate\Support\Facades\Route;

Route::inertia('/', 'welcome')->name('home');

Route::middleware(['auth', 'verified'])->group(function () {
    Route::inertia('dashboard', 'dashboard')->name('dashboard');
});

/*
| Printables opened from the Filament panel in a new tab. Auth only — the
| panel's own users reach these, and ReceiptController enforces the
| branch check itself.
*/
Route::middleware('auth')->group(function () {
    Route::get('labels/{product}', [LabelController::class, 'sheet'])->name('labels.sheet');
    Route::get('labels/{product}/qr', [LabelController::class, 'qr'])->name('labels.qr');
    Route::get('receipts/{sale}', ReceiptController::class)->name('receipts.show');
    Route::get('sales-report', SalesReportController::class)->name('sales.report');
});

require __DIR__.'/settings.php';
