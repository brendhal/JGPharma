<?php

namespace App\Enums;

use Filament\Support\Contracts\HasIcon;
use Filament\Support\Contracts\HasLabel;

enum PaymentMethod: string implements HasIcon, HasLabel
{
    case CASH = 'CASH';
    case CARD = 'CARD';
    case GCASH = 'GCASH';

    public function getLabel(): string
    {
        return match ($this) {
            self::CASH => 'Cash',
            self::CARD => 'Card',
            self::GCASH => 'GCash',
        };
    }

    public function getIcon(): string
    {
        return match ($this) {
            self::CASH => 'heroicon-m-banknotes',
            self::CARD => 'heroicon-m-credit-card',
            self::GCASH => 'heroicon-m-device-phone-mobile',
        };
    }
}
