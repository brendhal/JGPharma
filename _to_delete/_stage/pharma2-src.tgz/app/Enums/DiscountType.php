<?php

namespace App\Enums;

use Filament\Support\Contracts\HasLabel;

enum DiscountType: string implements HasLabel
{
    case NONE = 'NONE';
    case SENIOR = 'SENIOR';
    case PWD = 'PWD';

    public function getLabel(): string
    {
        return match ($this) {
            self::NONE => 'Regular',
            self::SENIOR => 'Senior Citizen (20%)',
            self::PWD => 'PWD (20%)',
        };
    }

    /** Statutory percentage this discount grants. */
    public function percentage(): float
    {
        return match ($this) {
            self::NONE => 0.0,
            self::SENIOR => (float) config('pos.statutory_discounts.senior', 20),
            self::PWD => (float) config('pos.statutory_discounts.pwd', 20),
        };
    }

    /** Senior/PWD sales are exempt from VAT under Philippine law. */
    public function isVatExempt(): bool
    {
        return $this !== self::NONE;
    }
}
