<?php

namespace App\Support;

class Money
{
    /** "₱1,234.50" */
    public static function format(float|int|string|null $amount): string
    {
        return self::symbol().number_format((float) $amount, 2);
    }

    /** "1,234.50" — for receipts where the symbol is printed separately. */
    public static function plain(float|int|string|null $amount): string
    {
        return number_format((float) $amount, 2);
    }

    public static function symbol(): string
    {
        return (string) config('pos.currency.symbol', '₱');
    }

    public static function vatRate(): float
    {
        return (float) config('pos.vat.rate', 12);
    }

    public static function vatIsInclusive(): bool
    {
        return (bool) config('pos.vat.inclusive', true);
    }

    /**
     * Split a VAT-inclusive amount into its net and tax parts.
     *
     * @return array{net: float, vat: float}
     */
    public static function extractVat(float $grossAmount): array
    {
        $rate = self::vatRate() / 100;

        if ($rate <= 0) {
            return ['net' => round($grossAmount, 2), 'vat' => 0.0];
        }

        $net = $grossAmount / (1 + $rate);

        return [
            'net' => round($net, 2),
            'vat' => round($grossAmount - $net, 2),
        ];
    }

    /** Tax added on top of a VAT-exclusive amount. */
    public static function addVat(float $netAmount): array
    {
        $vat = round($netAmount * (self::vatRate() / 100), 2);

        return ['net' => round($netAmount, 2), 'vat' => $vat];
    }
}
