<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use Carbon\CarbonImmutable;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

/**
 * A printable sales summary for a day, week, month or year.
 *
 * Cashiers get their own transactions only; management sees every sale their
 * branch scope allows.
 */
class SalesReportController extends Controller
{
    /** @var array<int, string> */
    private const PERIODS = ['daily', 'weekly', 'monthly', 'yearly'];

    public function __invoke(Request $request): View
    {
        $period = $request->string('period')->lower()->toString();

        if (! in_array($period, self::PERIODS, true)) {
            $period = 'daily';
        }

        $anchor = rescue(
            fn (): CarbonImmutable => CarbonImmutable::parse($request->string('date')->toString()),
            CarbonImmutable::now(),
            report: false,
        );

        [$from, $to, $heading] = match ($period) {
            'weekly' => [
                $anchor->startOfWeek(),
                $anchor->endOfWeek(),
                'Week of '.$anchor->startOfWeek()->format('d M Y'),
            ],
            'monthly' => [
                $anchor->startOfMonth(),
                $anchor->endOfMonth(),
                $anchor->format('F Y'),
            ],
            'yearly' => [
                $anchor->startOfYear(),
                $anchor->endOfYear(),
                $anchor->format('Y'),
            ],
            default => [
                $anchor->startOfDay(),
                $anchor->endOfDay(),
                $anchor->format('l, d F Y'),
            ],
        };

        $user = $request->user();

        $sales = Sale::query()
            ->completed()
            ->with(['cashier', 'branch', 'items.product.medicine'])
            ->withCount('items')
            ->withSum('items as units_sold', 'quantity')
            ->when(
                ! $user->isManagement(),
                fn ($query) => $query->where('user_id', $user->id)
            )
            ->whereBetween('sale_date', [$from, $to])
            ->orderBy('sale_date')
            ->get();

        return view('reports.sales', [
            'sales' => $sales,
            'period' => $period,
            'heading' => $heading,
            'from' => $from,
            'to' => $to,
            'user' => $user,
            'scopedToSelf' => ! $user->isManagement(),
            'store' => config('pos.store'),
            'totals' => [
                'gross' => (float) $sales->sum(fn (Sale $sale) => (float) $sale->subtotal),
                'discount' => (float) $sales->sum(fn (Sale $sale) => (float) $sale->discount),
                'vat' => (float) $sales->sum(fn (Sale $sale) => (float) $sale->vat_amount),
                'net' => (float) $sales->sum(fn (Sale $sale) => (float) $sale->total_amount),
                'units' => (int) $sales->sum('units_sold'),
                'transactions' => $sales->count(),
            ],
            'byPaymentMethod' => $sales
                ->groupBy(fn (Sale $sale) => $sale->payment_method?->getLabel() ?? '—')
                ->map(fn ($group) => [
                    'count' => $group->count(),
                    'total' => (float) $group->sum(fn (Sale $sale) => (float) $sale->total_amount),
                ])
                ->sortKeys(),
            'byDay' => $sales
                ->groupBy(fn (Sale $sale) => $sale->sale_date->format('Y-m-d'))
                ->map(fn ($group) => [
                    'count' => $group->count(),
                    'total' => (float) $group->sum(fn (Sale $sale) => (float) $sale->total_amount),
                ])
                ->sortKeys(),
        ]);
    }
}
