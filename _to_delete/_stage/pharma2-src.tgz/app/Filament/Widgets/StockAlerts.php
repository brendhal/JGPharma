<?php

namespace App\Filament\Widgets;

use App\Filament\Resources\PurchaseResource;
use App\Models\BranchInventory;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

/**
 * Everything at or below its reorder level, most urgent first.
 */
class StockAlerts extends BaseWidget
{
    protected static ?int $sort = 5;

    protected int|string|array $columnSpan = 1;

    protected static ?string $heading = 'Stock alerts';

    /** Store-wide figures — management only, never the floor. */
    public static function canView(): bool
    {
        return auth()->user()?->isManagement() ?? false;
    }

    public function table(Table $table): Table
    {
        return $table
            ->query(
                BranchInventory::query()
                    ->with('product.medicine')
                    ->whereRaw('quantity <= coalesce(minimum_stock, (select minimum_stock from products where products.id = branch_inventories.product_id))')
                    ->orderBy('quantity')
                    ->limit(8)
            )
            ->paginated(false)
            ->columns([
                Tables\Columns\TextColumn::make('product.name')
                    ->label('Product')
                    ->weight('semibold')
                    ->description(fn (BranchInventory $record): string => $record->quantity <= 0
                        ? 'Out of stock'
                        : $record->quantity.' left in stock')
                    ->color(fn (BranchInventory $record): string => $record->quantity <= 0 ? 'danger' : 'warning'),

                Tables\Columns\TextColumn::make('reorder_level')
                    ->label('Reorder at')
                    ->alignCenter(),
            ])
            ->actions([
                Tables\Actions\Action::make('reorder')
                    ->label('Reorder')
                    ->button()
                    ->url(fn (BranchInventory $record): string => PurchaseResource::getUrl('create', [
                        'product' => $record->product_id,
                        'branch' => $record->branch_id,
                        'quantity' => $record->suggested_reorder_quantity,
                    ])),
            ])
            ->emptyStateHeading('No stock alerts')
            ->emptyStateDescription('Every product is above its reorder level.');
    }
}
