<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProductResource\Pages;
use App\Filament\Resources\ProductResource\RelationManagers\BatchesRelationManager;
use App\Filament\Resources\ProductResource\RelationManagers\StockRelationManager;
use App\Models\Product;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;

class ProductResource extends Resource
{
    protected static ?string $model = Product::class;

    protected static ?string $navigationIcon = 'heroicon-o-cube';

    protected static ?string $navigationGroup = 'Catalog';

    protected static ?string $navigationLabel = 'Products & Medicines';

    protected static ?int $navigationSort = 1;

    protected static ?string $recordTitleAttribute = 'name';

    public static function canViewAny(): bool
    {
        return auth()->user()?->isManagement() ?? false;
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Product details')
                ->description('What the item is called, how it is classified, and how it scans.')
                ->icon('heroicon-o-cube')
                ->schema([
                    Forms\Components\TextInput::make('name')
                        ->label('Product name')
                        ->required()
                        ->maxLength(255)
                        ->live(onBlur: true)
                        ->afterStateUpdated(function (Forms\Set $set, ?string $state, string $operation) {
                            if ($operation === 'create' && filled($state)) {
                                $set('sku', Str::upper(Str::slug(Str::limit($state, 20, ''), '-')).'-'.random_int(100, 999));
                            }
                        })
                        ->columnSpan(2),

                    Forms\Components\Select::make('category_id')
                        ->label('Category')
                        ->relationship('category', 'name')
                        ->searchable()
                        ->preload()
                        ->createOptionForm([
                            Forms\Components\TextInput::make('name')->required(),
                            Forms\Components\Select::make('parent_id')
                                ->label('Parent category')
                                ->relationship('parent', 'name')
                                ->searchable(),
                        ]),

                    Forms\Components\Select::make('brand_id')
                        ->label('Brand')
                        ->relationship('brand', 'name')
                        ->searchable()
                        ->preload()
                        ->createOptionForm([
                            Forms\Components\TextInput::make('name')->required(),
                        ]),

                    Forms\Components\TextInput::make('sku')
                        ->label('SKU')
                        ->required()
                        ->unique(ignoreRecord: true)
                        ->maxLength(60)
                        ->helperText('Internal code. Printed on the QR sticker when no barcode exists.'),

                    Forms\Components\TextInput::make('barcode')
                        ->label('Barcode / QR value')
                        ->unique(ignoreRecord: true)
                        ->maxLength(60)
                        ->helperText('Scan the manufacturer barcode straight into this field.'),

                    Forms\Components\TextInput::make('unit')
                        ->label('Selling unit')
                        ->required()
                        ->datalist(['Piece', 'Box', 'Strip', 'Bottle', 'Sachet', 'Vial', 'Inhaler', 'Tube'])
                        ->maxLength(50)
                        ->helperText('The whole pack as it sits on the shelf.'),

                    Forms\Components\TextInput::make('piece_unit')
                        ->label('Piece is called')
                        ->datalist(['Tab', 'Cap', 'pcs', 'ml', 'Sachet'])
                        ->maxLength(30)
                        ->helperText('Leave blank if the pack is never broken open.'),

                    Forms\Components\TextInput::make('pieces_per_box')
                        ->label('Pieces per pack')
                        ->numeric()
                        ->minValue(1)
                        ->default(1)
                        ->required()
                        ->helperText('20 for a box of 20 tablets. 1 means it is sold whole only.'),

                    Forms\Components\TextInput::make('pieces_per_pack')
                        ->label('Pieces per blister')
                        ->numeric()
                        ->minValue(1)
                        ->helperText('Optional. 10 if the box holds blisters of 10.')
                        ->lte('pieces_per_box'),

                    Forms\Components\FileUpload::make('image_path')
                        ->label('Photo')
                        ->image()
                        ->imageEditor()
                        ->directory('products')
                        ->visibility('public'),
                ])
                ->columns(3),

            Forms\Components\Section::make('Pricing & stock control')
                ->icon('heroicon-o-banknotes')
                ->schema([
                    Forms\Components\TextInput::make('cost_price')
                        ->label('Cost price')
                        ->numeric()
                        ->prefix('₱')
                        ->default(0)
                        ->required()
                        ->live(onBlur: true),

                    Forms\Components\TextInput::make('selling_price')
                        ->label('Selling price')
                        ->numeric()
                        ->prefix('₱')
                        ->default(0)
                        ->required()
                        ->live(onBlur: true),

                    Forms\Components\Placeholder::make('margin')
                        ->label('Margin')
                        ->content(function (Forms\Get $get): string {
                            $cost = (float) $get('cost_price');
                            $price = (float) $get('selling_price');

                            if ($price <= 0) {
                                return '—';
                            }

                            $margin = (($price - $cost) / $price) * 100;

                            return number_format($margin, 1).'%  (₱'.number_format($price - $cost, 2).' per unit)';
                        }),

                    Forms\Components\TextInput::make('minimum_stock')
                        ->label('Reorder level')
                        ->numeric()
                        ->default(10)
                        ->required()
                        ->helperText('The dashboard raises a low-stock alert at or below this.'),

                    Forms\Components\Toggle::make('is_batch_tracked')
                        ->label('Track batches & expiry')
                        ->default(true)
                        ->helperText('On for medicines. Off for merchandise that never expires.'),

                    Forms\Components\Toggle::make('is_vat_exempt')
                        ->label('VAT exempt')
                        ->default(false),

                    Forms\Components\Toggle::make('is_active')
                        ->label('Active')
                        ->default(true),
                ])
                ->columns(3),

            Forms\Components\Section::make('Medicine information')
                ->description('Fill this in only for drugs. Leave the toggle off for general merchandise.')
                ->icon('heroicon-o-beaker')
                ->schema([
                    Forms\Components\Toggle::make('is_medicine')
                        ->label('This product is a medicine')
                        ->live()
                        ->dehydrated(false)
                        ->afterStateHydrated(function (Forms\Components\Toggle $component, ?Product $record) {
                            $component->state((bool) $record?->medicine);
                        }),

                    Forms\Components\Group::make()
                        ->relationship('medicine')
                        ->schema([
                            Forms\Components\TextInput::make('generic_name')
                                ->label('Generic name')
                                ->required()
                                ->maxLength(255),

                            Forms\Components\TextInput::make('strength')
                                ->label('Strength')
                                ->placeholder('500mg')
                                ->maxLength(100),

                            Forms\Components\Select::make('dosage_form')
                                ->label('Dosage form')
                                ->options([
                                    'Tablet' => 'Tablet',
                                    'Capsule' => 'Capsule',
                                    'Syrup' => 'Syrup',
                                    'Suspension' => 'Suspension',
                                    'Injection' => 'Injection',
                                    'Inhaler' => 'Inhaler',
                                    'Ointment' => 'Ointment',
                                    'Drops' => 'Drops',
                                    'Suppository' => 'Suppository',
                                ])
                                ->searchable(),

                            Forms\Components\TextInput::make('manufacturer')
                                ->maxLength(255),

                            Forms\Components\TextInput::make('registration_number')
                                ->label('FDA registration no.')
                                ->maxLength(100),

                            Forms\Components\Toggle::make('requires_prescription')
                                ->label('Prescription required (Rx)')
                                ->helperText('The POS will ask the cashier to confirm a prescription.'),
                        ])
                        ->columns(3)
                        ->visible(fn (Forms\Get $get): bool => (bool) $get('is_medicine')),
                ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        $branchId = auth()->user()?->branch_id;

        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query
                ->with(['category', 'brand', 'medicine'])
                ->withSum(
                    ['inventories as stock_on_hand' => fn ($q) => $branchId ? $q->where('branch_id', $branchId) : $q],
                    'quantity'
                ))
            ->columns([
                Tables\Columns\TextColumn::make('barcode')
                    ->label('Barcode')
                    ->searchable()
                    ->copyable()
                    ->color('gray')
                    ->placeholder('—')
                    ->toggleable(),

                Tables\Columns\TextColumn::make('medicine.generic_name')
                    ->label('Generic name')
                    ->searchable()
                    ->description(fn (Product $record): ?string => $record->medicine?->strength)
                    ->placeholder('—'),

                Tables\Columns\TextColumn::make('name')
                    ->label('Brand name')
                    ->searchable()
                    ->weight('semibold')
                    ->description(fn (Product $record): ?string => $record->category?->name),

                Tables\Columns\TextColumn::make('unit')
                    ->label('Unit')
                    ->formatStateUsing(fn (Product $record): string => $record->isDivisible()
                        ? "{$record->unit} ({$record->pieces_per_box} {$record->piece_unit})"
                        : (string) $record->unit)
                    ->toggleable(),

                Tables\Columns\TextColumn::make('cost_price')
                    ->label('Cost')
                    ->money('PHP')
                    ->alignEnd()
                    ->toggleable(),

                Tables\Columns\TextColumn::make('selling_price')
                    ->label('Price')
                    ->money('PHP')
                    ->alignEnd()
                    ->color('primary')
                    ->weight('semibold')
                    ->sortable(),

                Tables\Columns\TextColumn::make('stock_on_hand')
                    ->label('Stock')
                    ->badge()
                    ->alignCenter()
                    ->default(0)
                    ->formatStateUsing(function ($state, Product $record): string {
                        $qty = (int) $state;

                        if ($qty <= 0) {
                            return 'Out of stock';
                        }

                        $reads = $record->formatPieces($qty);

                        return $qty <= $record->minimum_stock ? "{$reads} · low" : $reads;
                    })
                    ->color(function ($state, Product $record): string {
                        $qty = (int) $state;

                        return match (true) {
                            $qty <= 0 => 'danger',
                            $qty <= $record->minimum_stock => 'warning',
                            default => 'success',
                        };
                    })
                    ->sortable(),

                Tables\Columns\IconColumn::make('medicine.requires_prescription')
                    ->label('Rx')
                    ->boolean()
                    ->trueIcon('heroicon-o-clipboard-document-check')
                    ->falseIcon('heroicon-o-minus-small')
                    ->trueColor('warning')
                    ->falseColor('gray')
                    ->toggleable(),

                Tables\Columns\IconColumn::make('is_active')
                    ->label('Active')
                    ->boolean()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('category_id')
                    ->label('Category')
                    ->relationship('category', 'name')
                    ->searchable()
                    ->preload(),

                Tables\Filters\SelectFilter::make('brand_id')
                    ->label('Brand')
                    ->relationship('brand', 'name')
                    ->searchable()
                    ->preload(),

                Tables\Filters\TernaryFilter::make('medicine')
                    ->label('Medicines only')
                    ->queries(
                        true: fn (Builder $q) => $q->whereHas('medicine'),
                        false: fn (Builder $q) => $q->whereDoesntHave('medicine'),
                        blank: fn (Builder $q) => $q,
                    ),

                Tables\Filters\Filter::make('low_stock')
                    ->label('Low stock only')
                    ->query(fn (Builder $query) => $query->whereHas('inventories', fn (Builder $i) => $i
                        ->whereRaw('branch_inventories.quantity <= coalesce(branch_inventories.minimum_stock, products.minimum_stock)')))
                    ->toggle(),

                Tables\Filters\TernaryFilter::make('is_active')
                    ->label('Active')
                    ->default(true),
            ])
            ->actions([
                Tables\Actions\ActionGroup::make([
                    Tables\Actions\EditAction::make(),
                    Tables\Actions\Action::make('labels')
                        ->label('Print QR stickers')
                        ->icon('heroicon-o-qr-code')
                        ->color('gray')
                        ->url(fn (Product $record): string => route('labels.sheet', $record))
                        ->openUrlInNewTab(),
                    Tables\Actions\DeleteAction::make(),
                ]),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('name')
            ->striped();
    }

    public static function getRelations(): array
    {
        return [
            StockRelationManager::class,
            BatchesRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListProducts::route('/'),
            'create' => Pages\CreateProduct::route('/create'),
            'edit' => Pages\EditProduct::route('/{record}/edit'),
        ];
    }

    public static function getGloballySearchableAttributes(): array
    {
        return ['name', 'sku', 'barcode', 'medicine.generic_name'];
    }

    public static function getGlobalSearchResultDetails($record): array
    {
        return [
            'Generic' => $record->medicine?->generic_name ?? '—',
            'Price' => '₱'.number_format((float) $record->selling_price, 2),
        ];
    }
}
