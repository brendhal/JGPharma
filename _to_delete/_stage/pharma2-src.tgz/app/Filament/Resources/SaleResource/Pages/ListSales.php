<?php

namespace App\Filament\Resources\SaleResource\Pages;

use App\Filament\Pages\PointOfSale;
use App\Filament\Resources\SaleResource;
use Filament\Actions;
use Filament\Forms;
use Filament\Resources\Pages\ListRecords;

class ListSales extends ListRecords
{
    protected static string $resource = SaleResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('printReport')
                ->label('Print sales report')
                ->icon('heroicon-o-printer')
                ->color('gray')
                ->modalHeading('Print sales report')
                ->modalSubmitActionLabel('Open report')
                ->form([
                    Forms\Components\Select::make('period')
                        ->label('Period')
                        ->options([
                            'daily' => 'Daily',
                            'weekly' => 'Weekly',
                            'monthly' => 'Monthly',
                            'yearly' => 'Yearly',
                        ])
                        ->default('daily')
                        ->required()
                        ->native(false),

                    Forms\Components\DatePicker::make('date')
                        ->label('Any date inside the period')
                        ->helperText('The report covers the day, week, month or year containing this date.')
                        ->default(now())
                        ->maxDate(now())
                        ->required(),
                ])
                ->action(fn (array $data) => redirect()->route('sales.report', [
                    'period' => $data['period'],
                    'date' => $data['date'],
                ])),

            Actions\Action::make('newSale')
                ->label('New sale')
                ->icon('heroicon-o-shopping-cart')
                ->url(fn (): string => PointOfSale::getUrl()),
        ];
    }
}
