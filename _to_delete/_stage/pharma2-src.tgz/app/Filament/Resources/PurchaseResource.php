<?php

namespace App\Filament\Resources;

use App\Enums\PurchaseStatus;
use App\Filament\Resources\PurchaseResource\Pages;
use App\Models\Product;
use App\Models\Purchase;
use App\Services\InventoryService;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class PurchaseResource extends Resource
{
    protected static ?string $model = Purchase::class;

    protected static ?string $navigationIcon = 'heroicon-o-truck';

    protected static ?string $navigationGroup = 'Purchasing';

    protected static ?string $navigationLabel = 'Purchase orders';

    protected static ?int $navigationSort = 2;

    protected static ?string $recordTitleAttribute = 'reference_number';

    public static function canViewAny(): bool
    {
        return auth()->user()?->isManagement() ?? false;
    }

    public static function getNavigationBadge(): ?string
    {
        $pending = Purchase::query()->where('status', PurchaseStatus::PENDING)->count();

        return $pending > 0 ? (string) $pending : null;
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Order header')
                ->schema([
                    Forms\Components\Select::make('supplier_id')
                        ->label('Supplier')
                        ->relationship('supplier', 'name', fn (Builder $query) => $query->where('is_active', true))
                        ->searchable()
                        ->preload()
                        ->required(),

                    Forms\Components\Select::make('branch_id')
                        ->label('Receiving branch')
                        ->relationship('branch', 'name')
                        ->default(fn (): mixed => request()->integer('branch') ?: auth()->user()?->branch_id)
                        ->disabled(fn (): bool => ! auth()->user()->seesAllBranches())
                        ->dehydrated()
                        ->required(),

                    Forms\Components\DatePicker::make('purchase_date')
                        ->label('Purchase date')
                        ->default(now())
                        ->native(false)
                        ->required(),

                    Forms\Components\Placeholder::make('reference_number')
                        ->label('Reference no.')
                        ->content(fn (?Purchase $record): string => $record?->reference_number ?? 'Generated on save'),
                ])
                ->columns(4),

            Forms\Components\Section::make('Items')
                ->schema([
                    Forms\Components\Repeater::make('items')
                        ->relationship()
                        ->label('')
                        ->schema([
                            Forms\Components\Select::make('product_id')
                                ->label('Product')
                                ->options(fn () => Product::active()->orderBy('name')->pluck('name', 'id'))
                                ->searchable()
                                ->required()
                                ->live()
                                ->afterStateUpdated(function (Forms\Set $set, $state) {
                                    if ($product = Product::find($state)) {
                                        $set('cost_price', $product->cost_price);
                                    }
                                })
                                ->columnSpan(2),

                            Forms\Components\TextInput::make('batch_number')
                                ->label('Batch no.')
                                ->maxLength(60),

                            Forms\Components\DatePicker::make('expiration_date')
                                ->label('Expires')
                                ->native(false),

                            Forms\Components\TextInput::make('quantity')
                                ->label('Qty')
                                ->numeric()
                                ->minValue(1)
                                ->default(1)
                                ->required()
                                ->live(onBlur: true),

                            Forms\Components\TextInput::make('cost_price')
                                ->label('Unit cost')
                                ->numeric()
                                ->prefix('₱')
                                ->required()
                                ->live(onBlur: true),

                            Forms\Components\Placeholder::make('line_total')
                                ->label('Subtotal')
                                ->content(fn (Forms\Get $get): string => '₱'.number_format(
                                    ((float) $get('quantity')) * ((float) $get('cost_price')),
                                    2
                                )),
                        ])
                        ->columns(7)
                        ->defaultItems(1)
                        ->default(fn (): array => static::reorderDefaultItems())
                        ->addActionLabel('Add item')
                        ->disabled(fn (?Purchase $record): bool => $record?->isReceived() ?? false)
                        ->required(),
                ]),

            Forms\Components\Textarea::make('remarks')
                ->rows(2)
                ->columnSpanFull(),
        ]);
    }

    /**
     * The opening line of the Items repeater.
     *
     * The Reorder button on the dashboard's stock alerts hands over the
     * product, a suggested quantity and the branch that ran short, so the
     * order opens ready to price rather than blank. Anywhere else the form is
     * reached, this is the usual single empty row.
     *
     * @return array<int, array<string, mixed>>
     */
    protected static function reorderDefaultItems(): array
    {
        $product = Product::active()->find(request()->integer('product'));

        if (! $product) {
            return [[]];
        }

        return [[
            'product_id' => $product->id,
            'quantity' => max(1, request()->integer('quantity')),
            'cost_price' => $product->cost_price,
        ]];
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(fn (Builder $query) => $query->with(['supplier', 'branch', 'creator'])->withCount('items'))
            ->columns([
                Tables\Columns\TextColumn::make('reference_number')
                    ->label('Reference')
                    ->searchable()
                    ->fontFamily('mono')
                    ->weight('semibold'),

                Tables\Columns\TextColumn::make('purchase_date')
                    ->label('Date')
                    ->date('d M Y')
                    ->sortable(),

                Tables\Columns\TextColumn::make('supplier.name')
                    ->label('Supplier')
                    ->searchable()
                    ->description(fn (Purchase $record): ?string => $record->branch?->name),

                Tables\Columns\TextColumn::make('items_count')
                    ->label('Lines')
                    ->badge()
                    ->alignCenter(),

                Tables\Columns\TextColumn::make('total_amount')
                    ->label('Total')
                    ->money('PHP')
                    ->alignEnd()
                    ->weight('bold')
                    ->sortable(),

                Tables\Columns\TextColumn::make('status')
                    ->badge(),

                Tables\Columns\TextColumn::make('creator.name')
                    ->label('Encoded by')
                    ->placeholder('—')
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->options(PurchaseStatus::class),

                Tables\Filters\SelectFilter::make('supplier_id')
                    ->label('Supplier')
                    ->relationship('supplier', 'name')
                    ->searchable(),
            ])
            ->actions([
                Tables\Actions\Action::make('receive')
                    ->label('Receive')
                    ->icon('heroicon-o-check-circle')
                    ->color('success')
                    ->requiresConfirmation()
                    ->modalHeading('Receive this delivery?')
                    ->modalDescription('Batches will be created and stock levels updated. This cannot be undone.')
                    ->visible(fn (Purchase $record): bool => $record->status === PurchaseStatus::PENDING)
                    ->action(function (Purchase $record, InventoryService $inventory) {
                        try {
                            $inventory->receivePurchase($record);

                            Notification::make()
                                ->title('Delivery received')
                                ->body("Stock updated from {$record->reference_number}.")
                                ->success()
                                ->send();
                        } catch (\Throwable $e) {
                            Notification::make()
                                ->title('Could not receive delivery')
                                ->body($e->getMessage())
                                ->danger()
                                ->send();
                        }
                    }),

                Tables\Actions\EditAction::make(),

                Tables\Actions\DeleteAction::make()
                    ->visible(fn (Purchase $record): bool => $record->status !== PurchaseStatus::RECEIVED),
            ])
            ->defaultSort('purchase_date', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPurchases::route('/'),
            'create' => Pages\CreatePurchase::route('/create'),
            'edit' => Pages\EditPurchase::route('/{record}/edit'),
        ];
    }
}
