<?php

namespace App\Filament\Resources\StockMovementResource\Pages;

use App\Enums\MovementType;
use App\Filament\Resources\StockMovementResource;
use App\Models\Branch;
use App\Models\Product;
use App\Models\ProductBatch;
use App\Models\Purchase;
use App\Models\Supplier;
use App\Services\InventoryService;
use Filament\Actions;
use Filament\Forms;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Support\Facades\DB;

class ListStockMovements extends ListRecords
{
    protected static string $resource = StockMovementResource::class;

    protected static ?string $title = 'Stock & inventory control';

    protected function getHeaderActions(): array
    {
        return [
            $this->receiveGoodsAction(),
            $this->recordDisposalAction(),
            $this->adjustLevelsAction(),
        ];
    }

    /**
     * Stock In — book a delivery from a supplier and create its batches.
     */
    protected function receiveGoodsAction(): Actions\Action
    {
        return Actions\Action::make('receiveGoods')
            ->label('Receive goods')
            ->icon('heroicon-o-arrow-down-tray')
            ->color('primary')
            ->modalWidth('5xl')
            ->modalHeading('Receive new shipment')
            ->modalDescription('Records the delivery, creates a batch per line, and updates stock levels.')
            ->form([
                Forms\Components\Grid::make(3)->schema([
                    Forms\Components\Select::make('supplier_id')
                        ->label('Supplier')
                        ->options(fn () => Supplier::where('is_active', true)->orderBy('name')->pluck('name', 'id'))
                        ->searchable()
                        ->required(),

                    Forms\Components\Select::make('branch_id')
                        ->label('Receiving branch')
                        ->options(fn () => Branch::where('is_active', true)->orderBy('name')->pluck('name', 'id'))
                        ->default(auth()->user()?->branch_id)
                        ->disabled(fn (): bool => ! auth()->user()->seesAllBranches())
                        ->dehydrated()
                        ->required(),

                    Forms\Components\DatePicker::make('purchase_date')
                        ->label('Delivery date')
                        ->default(now())
                        ->native(false)
                        ->required(),
                ]),

                Forms\Components\Repeater::make('items')
                    ->label('Delivered items')
                    ->schema([
                        Forms\Components\Select::make('product_id')
                            ->label('Product')
                            ->options(fn () => Product::active()->orderBy('name')->pluck('name', 'id'))
                            ->searchable()
                            ->required()
                            ->live()
                            ->afterStateUpdated(function (Forms\Set $set, $state) {
                                if ($product = Product::find($state)) {
                                    $set('cost_price', $product->cost_price);
                                }
                            })
                            ->columnSpan(2),

                        Forms\Components\TextInput::make('batch_number')
                            ->label('Batch no.')
                            ->maxLength(60),

                        Forms\Components\DatePicker::make('expiration_date')
                            ->label('Expires')
                            ->native(false),

                        Forms\Components\TextInput::make('quantity')
                            ->label('Qty')
                            ->numeric()
                            ->minValue(1)
                            ->default(1)
                            ->required(),

                        Forms\Components\TextInput::make('cost_price')
                            ->label('Unit cost')
                            ->numeric()
                            ->prefix('₱')
                            ->required(),
                    ])
                    ->columns(6)
                    ->defaultItems(1)
                    ->addActionLabel('Add another item')
                    ->required(),

                Forms\Components\Textarea::make('remarks')
                    ->label('Remarks')
                    ->rows(2)
                    ->placeholder('Delivery receipt no., driver name, etc.'),
            ])
            ->action(function (array $data, InventoryService $inventory) {
                DB::transaction(function () use ($data, $inventory) {
                    $purchase = Purchase::create([
                        'branch_id' => $data['branch_id'],
                        'supplier_id' => $data['supplier_id'],
                        'purchase_date' => $data['purchase_date'],
                        'remarks' => $data['remarks'] ?? null,
                    ]);

                    foreach ($data['items'] as $item) {
                        $purchase->items()->create([
                            'product_id' => $item['product_id'],
                            'batch_number' => $item['batch_number'] ?? null,
                            'expiration_date' => $item['expiration_date'] ?? null,
                            'quantity' => (int) $item['quantity'],
                            'cost_price' => (float) $item['cost_price'],
                        ]);
                    }

                    $inventory->receivePurchase($purchase->fresh('items', 'supplier'));

                    Notification::make()
                        ->title('Shipment received')
                        ->body("Purchase {$purchase->reference_number} added ".count($data['items']).' item line(s) to stock.')
                        ->success()
                        ->send();
                });
            });
    }

    /**
     * Stock Out — write off expired or damaged goods.
     */
    protected function recordDisposalAction(): Actions\Action
    {
        return Actions\Action::make('recordDisposal')
            ->label('Record disposal')
            ->icon('heroicon-o-trash')
            ->color('gray')
            ->modalHeading('Record expired or damaged stock')
            ->form([
                Forms\Components\Select::make('product_batch_id')
                    ->label('Batch')
                    ->required()
                    ->searchable()
                    ->getSearchResultsUsing(fn (string $search) => ProductBatch::query()
                        ->inStock()
                        ->with('product')
                        ->where(fn ($q) => $q
                            ->whereHas('product', fn ($p) => $p->where('name', 'like', "%{$search}%"))
                            ->orWhere('batch_number', 'like', "%{$search}%"))
                        ->limit(25)
                        ->get()
                        ->mapWithKeys(fn (ProductBatch $batch) => [
                            $batch->id => "{$batch->product->name} — {$batch->batch_number} ({$batch->quantity} left)",
                        ]))
                    ->getOptionLabelUsing(function ($value): ?string {
                        $batch = ProductBatch::with('product')->find($value);

                        return $batch ? "{$batch->product->name} — {$batch->batch_number}" : null;
                    })
                    ->helperText('Search by product name or batch number.'),

                Forms\Components\Select::make('type')
                    ->label('Reason')
                    ->options([
                        MovementType::EXPIRED->value => 'Expired',
                        MovementType::DAMAGED->value => 'Damaged',
                    ])
                    ->default(MovementType::EXPIRED->value)
                    ->native(false)
                    ->required(),

                Forms\Components\TextInput::make('quantity')
                    ->label('Quantity')
                    ->numeric()
                    ->minValue(1)
                    ->required(),

                Forms\Components\Textarea::make('remarks')
                    ->rows(2)
                    ->placeholder('Expired items disposal'),
            ])
            ->action(function (array $data, InventoryService $inventory) {
                $batch = ProductBatch::findOrFail($data['product_batch_id']);

                $inventory->dispose(
                    batch: $batch,
                    quantity: (int) $data['quantity'],
                    type: MovementType::from($data['type']),
                    remarks: $data['remarks'] ?? null,
                );

                Notification::make()
                    ->title('Disposal recorded')
                    ->body("{$data['quantity']} unit(s) removed from batch {$batch->batch_number}.")
                    ->success()
                    ->send();
            });
    }

    /**
     * Adjustment — reconcile the system with a physical count.
     */
    protected function adjustLevelsAction(): Actions\Action
    {
        return Actions\Action::make('adjustLevels')
            ->label('Adjust levels')
            ->icon('heroicon-o-adjustments-horizontal')
            ->color('warning')
            ->modalHeading('Inventory adjustment')
            ->modalDescription('Use after a physical audit. The difference is logged as an ADJUSTMENT movement.')
            ->form([
                Forms\Components\Select::make('branch_id')
                    ->label('Branch')
                    ->options(fn () => Branch::where('is_active', true)->orderBy('name')->pluck('name', 'id'))
                    ->default(auth()->user()?->branch_id)
                    ->disabled(fn (): bool => ! auth()->user()->seesAllBranches())
                    ->dehydrated()
                    ->required()
                    ->live()
                    ->helperText(fn (): ?string => auth()->user()->seesAllBranches()
                        ? 'Adjustments are counted against one branch at a time.'
                        : null),

                Forms\Components\Select::make('product_id')
                    ->label('Product')
                    ->options(fn () => Product::active()->orderBy('name')->pluck('name', 'id'))
                    ->searchable()
                    ->required()
                    ->live(),

                Forms\Components\Placeholder::make('system_quantity')
                    ->label('System quantity')
                    ->content(function (Forms\Get $get, InventoryService $inventory): string {
                        $productId = $get('product_id');
                        $branchId = $get('branch_id');

                        if (! $productId || ! $branchId) {
                            return '—';
                        }

                        return (string) $inventory->availableStock((int) $branchId, (int) $productId);
                    }),

                Forms\Components\TextInput::make('counted_quantity')
                    ->label('Counted quantity')
                    ->numeric()
                    ->required(),

                Forms\Components\Textarea::make('remarks')
                    ->label('Reason')
                    ->rows(2)
                    ->required()
                    ->placeholder('Physical audit discrepancy'),
            ])
            ->action(function (array $data, InventoryService $inventory) {
                $movement = $inventory->adjust(
                    branchId: (int) $data['branch_id'],
                    productId: (int) $data['product_id'],
                    countedQuantity: (int) $data['counted_quantity'],
                    remarks: $data['remarks'],
                );

                Notification::make()
                    ->title($movement ? 'Adjustment recorded' : 'Nothing to adjust')
                    ->body($movement
                        ? "Logged {$movement->signed_quantity} against the system count."
                        : 'The counted quantity already matches the system.')
                    ->success()
                    ->send();
            });
    }
}
