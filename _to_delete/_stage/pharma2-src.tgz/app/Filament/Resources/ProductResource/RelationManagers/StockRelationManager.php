<?php

namespace App\Filament\Resources\ProductResource\RelationManagers;

use App\Models\BranchInventory;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;

class StockRelationManager extends RelationManager
{
    protected static string $relationship = 'inventories';

    protected static ?string $title = 'Stock per branch';

    protected static ?string $icon = 'heroicon-o-building-storefront';

    public function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Select::make('branch_id')
                ->label('Branch')
                ->relationship('branch', 'name')
                ->required(),

            Forms\Components\TextInput::make('minimum_stock')
                ->label('Reorder level for this branch')
                ->numeric()
                ->helperText('Leave blank to use the product-wide reorder level.'),
        ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('branch.name')
                    ->label('Branch')
                    ->weight('semibold'),

                Tables\Columns\TextColumn::make('quantity')
                    ->label('On hand')
                    ->alignCenter()
                    ->badge()
                    ->color(fn (BranchInventory $record): string => match ($record->status) {
                        'Out of Stock' => 'danger',
                        'Low Stock' => 'warning',
                        default => 'success',
                    })
                    ->sortable(),

                Tables\Columns\TextColumn::make('reorder_level')
                    ->label('Reorder at')
                    ->alignCenter(),

                Tables\Columns\TextColumn::make('status')
                    ->label('Status')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'Out of Stock' => 'danger',
                        'Low Stock' => 'warning',
                        default => 'success',
                    }),
            ])
            ->actions([
                Tables\Actions\EditAction::make()
                    ->label('Set reorder level'),
            ])
            ->paginated(false);
    }

    public function isReadOnly(): bool
    {
        return false;
    }
}
