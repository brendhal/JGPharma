<?php

namespace App\Services;

use App\Enums\DiscountType;
use App\Enums\MovementType;
use App\Enums\PaymentMethod;
use App\Enums\SaleStatus;
use App\Enums\SellingUnit;
use App\Models\Product;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\StockMovement;
use App\Support\Money;
use Illuminate\Support\Facades\DB;
use RuntimeException;

/**
 * Turns a cart into a Sale: prices it, takes the money, and moves the stock.
 */
class PosService
{
    public function __construct(protected InventoryService $inventory) {}

    /**
     * Price a cart without touching the database.
     *
     * @param  array<int, array{product_id:int, quantity:int, unit?:string, unit_price:float, discount_percent?:float}>  $cart
     * @return array{gross: float, line_discount: float, subtotal: float, discount: float, vat: float, vat_exempt: bool, total: float}
     */
    public function totals(array $cart, DiscountType $discountType = DiscountType::NONE, float $discountPercent = 0): array
    {
        $gross = 0.0;
        $lineDiscount = 0.0;

        foreach ($cart as $line) {
            $lineGross = (float) $line['unit_price'] * (int) $line['quantity'];
            $lineOff = $lineGross * ((float) ($line['discount_percent'] ?? 0) / 100);

            $gross += $lineGross;
            $lineDiscount += $lineOff;
        }

        $subtotal = round($gross - $lineDiscount, 2);

        // Senior / PWD: the sale becomes VAT-exempt and the 20% statutory
        // discount is computed on the VAT-less price, per BIR rules.
        if ($discountType->isVatExempt()) {
            $net = Money::vatIsInclusive()
                ? Money::extractVat($subtotal)['net']
                : $subtotal;

            $discount = round($net * ($discountType->percentage() / 100), 2);

            return [
                'gross' => round($gross, 2),
                'line_discount' => round($lineDiscount, 2),
                'subtotal' => $subtotal,
                'discount' => round($subtotal - $net + $discount, 2),
                'vat' => 0.0,
                'vat_exempt' => true,
                'total' => round($net - $discount, 2),
            ];
        }

        $manualDiscount = round($subtotal * (max(0, $discountPercent) / 100), 2);
        $payable = round($subtotal - $manualDiscount, 2);

        $tax = Money::vatIsInclusive()
            ? Money::extractVat($payable)
            : Money::addVat($payable);

        return [
            'gross' => round($gross, 2),
            'line_discount' => round($lineDiscount, 2),
            'subtotal' => $subtotal,
            'discount' => round($lineDiscount + $manualDiscount, 2),
            'vat' => $tax['vat'],
            'vat_exempt' => false,
            'total' => Money::vatIsInclusive() ? $payable : round($payable + $tax['vat'], 2),
        ];
    }

    /**
     * Commit the sale: writes the invoice, its lines, and the stock movements
     * in one transaction. Anything short on stock aborts the whole thing.
     *
     * @param  array<int, array{product_id:int, quantity:int, unit?:string, unit_price:float, discount_percent?:float}>  $cart
     */
    public function checkout(
        array $cart,
        int $branchId,
        float $amountPaid,
        PaymentMethod $paymentMethod = PaymentMethod::CASH,
        DiscountType $discountType = DiscountType::NONE,
        float $discountPercent = 0,
        ?string $customerName = null,
        ?string $discountIdNumber = null,
    ): Sale {
        if (empty($cart)) {
            throw new RuntimeException('The cart is empty.');
        }

        $totals = $this->totals($cart, $discountType, $discountPercent);

        if ($paymentMethod === PaymentMethod::CASH && $amountPaid + 0.001 < $totals['total']) {
            throw new RuntimeException('Cash received is less than the amount due.');
        }

        return DB::transaction(function () use (
            $cart, $branchId, $amountPaid, $paymentMethod, $discountType,
            $customerName, $discountIdNumber, $totals
        ) {
            $sale = Sale::create([
                'branch_id' => $branchId,
                'user_id' => auth()->id(),
                'sale_date' => now(),
                'subtotal' => $totals['subtotal'],
                'discount' => $totals['discount'],
                'vat_amount' => $totals['vat'],
                'total_amount' => $totals['total'],
                'amount_paid' => $amountPaid,
                'change_amount' => max(0, round($amountPaid - $totals['total'], 2)),
                'payment_method' => $paymentMethod,
                'status' => SaleStatus::COMPLETED,
                'customer_name' => $customerName,
                'discount_type' => $discountType,
                'discount_id_number' => $discountIdNumber,
            ]);

            foreach ($cart as $line) {
                $product = Product::findOrFail($line['product_id']);
                $quantity = (int) $line['quantity'];
                $unitPrice = (float) $line['unit_price'];
                $linePercent = (float) ($line['discount_percent'] ?? 0);
                $lineGross = $unitPrice * $quantity;
                $lineDiscount = round($lineGross * ($linePercent / 100), 2);

                // The customer buys units; the shelf gives up pieces.
                $sellingUnit = SellingUnit::tryFrom($line['unit'] ?? '') ?? $product->defaultSellingUnit();
                $multiplier = $product->piecesPer($sellingUnit);
                $pieces = $quantity * $multiplier;

                if ($product->is_batch_tracked) {
                    $allocation = $this->inventory->allocateFefo($branchId, $product->id, $pieces);
                } else {
                    $available = $this->inventory->availableStock($branchId, $product->id);

                    if ($available < $pieces) {
                        throw new RuntimeException(
                            "Only {$product->formatPieces($available)} left of {$product->name}."
                        );
                    }

                    $allocation = [['batch' => null, 'quantity' => $pieces]];
                }

                // One line per cart row. A box may be drawn from two lots when
                // the first runs dry, but the customer bought one box at one
                // price, so the receipt says so and the batch shown is
                // whichever lot supplied most of it. The stock movements below
                // keep the per-lot truth.
                $primary = collect($allocation)->sortByDesc('quantity')->first();

                // Costing is captured per box; restate it per unit sold so
                // margin on three loose tablets is not three boxes' worth.
                $boxCost = (float) ($primary['batch']?->cost_price ?? $product->cost_price);
                $unitCost = round($boxCost / max(1, (int) $product->pieces_per_box) * $multiplier, 2);

                SaleItem::create([
                    'sale_id' => $sale->id,
                    'product_id' => $product->id,
                    'product_batch_id' => $primary['batch']?->id,
                    'quantity' => $quantity,
                    'unit_label' => $sellingUnit->labelFor($product),
                    'unit_multiplier' => $multiplier,
                    'unit_price' => $unitPrice,
                    'cost_price' => $unitCost,
                    'discount' => $lineDiscount,
                    'subtotal' => round($lineGross - $lineDiscount, 2),
                ]);

                foreach ($allocation as $part) {
                    $this->inventory->record(
                        branchId: $branchId,
                        productId: $product->id,
                        type: MovementType::SALE,
                        quantity: -$part['quantity'],
                        batch: $part['batch'],
                        referenceType: Sale::class,
                        referenceId: $sale->id,
                        remarks: "Sold on {$sale->invoice_number}",
                    );
                }
            }

            return $sale->load('items.product', 'cashier', 'branch');
        });
    }

    /**
     * Void a completed sale and put every unit back where it came from.
     */
    public function void(Sale $sale, ?string $reason = null): Sale
    {
        if (! $sale->isVoidable()) {
            throw new RuntimeException('Only completed sales can be voided.');
        }

        return DB::transaction(function () use ($sale, $reason) {
            // Reverse what actually left the shelf, lot by lot, rather than
            // working back from the sale lines — a line may have drawn on two
            // batches, and each one is owed its own pieces back.
            $sold = StockMovement::withoutGlobalScopes()
                ->with('batch')
                ->where('reference_type', Sale::class)
                ->where('reference_id', $sale->id)
                ->where('type', MovementType::SALE)
                ->get();

            foreach ($sold as $movement) {
                $this->inventory->record(
                    branchId: $sale->branch_id,
                    productId: $movement->product_id,
                    type: MovementType::RETURN,
                    quantity: abs($movement->quantity),
                    batch: $movement->batch,
                    referenceType: Sale::class,
                    referenceId: $sale->id,
                    remarks: "Void of {$sale->invoice_number}".($reason ? ": {$reason}" : ''),
                );
            }

            $sale->update([
                'status' => SaleStatus::VOIDED,
                'remarks' => trim(($sale->remarks ?? '')."\nVoided: ".($reason ?? 'no reason given')),
            ]);

            return $sale;
        });
    }

    /**
     * Look up a product by scanned QR/barcode or typed name.
     *
     * @return \Illuminate\Support\Collection<int, Product>
     */
    public function search(string $term, int $branchId, int $limit = 8)
    {
        return Product::query()
            ->active()
            ->with(['medicine', 'brand'])
            ->searchTerm($term)
            ->withSum(
                ['inventories as stock_on_hand' => fn ($q) => $q->where('branch_id', $branchId)],
                'quantity'
            )
            ->limit($limit)
            ->get();
    }
}
