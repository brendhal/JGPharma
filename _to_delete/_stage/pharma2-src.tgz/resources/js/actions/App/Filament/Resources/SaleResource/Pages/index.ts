import ListSales from './ListSales'
import ViewSale from './ViewSale'

const Pages = {
    ListSales: Object.assign(ListSales, ListSales),
    ViewSale: Object.assign(ViewSale, ViewSale),
}

export default Pages