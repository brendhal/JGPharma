import Pages from './Pages'

const SupplierResource = {
    Pages: Object.assign(Pages, Pages),
}

export default SupplierResource