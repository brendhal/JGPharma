import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\StockTransferResource\Pages\CreateStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/CreateStockTransfer.php:7
* @route '/admin/stock-transfers/create'
*/
const CreateStockTransfer = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: CreateStockTransfer.url(options),
    method: 'get',
})

CreateStockTransfer.definition = {
    methods: ["get","head"],
    url: '/admin/stock-transfers/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\CreateStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/CreateStockTransfer.php:7
* @route '/admin/stock-transfers/create'
*/
CreateStockTransfer.url = (options?: RouteQueryOptions) => {
    return CreateStockTransfer.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\CreateStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/CreateStockTransfer.php:7
* @route '/admin/stock-transfers/create'
*/
CreateStockTransfer.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: CreateStockTransfer.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\CreateStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/CreateStockTransfer.php:7
* @route '/admin/stock-transfers/create'
*/
CreateStockTransfer.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: CreateStockTransfer.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\CreateStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/CreateStockTransfer.php:7
* @route '/admin/stock-transfers/create'
*/
const CreateStockTransferForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: CreateStockTransfer.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\CreateStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/CreateStockTransfer.php:7
* @route '/admin/stock-transfers/create'
*/
CreateStockTransferForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: CreateStockTransfer.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\CreateStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/CreateStockTransfer.php:7
* @route '/admin/stock-transfers/create'
*/
CreateStockTransferForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: CreateStockTransfer.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

CreateStockTransfer.form = CreateStockTransferForm

export default CreateStockTransfer