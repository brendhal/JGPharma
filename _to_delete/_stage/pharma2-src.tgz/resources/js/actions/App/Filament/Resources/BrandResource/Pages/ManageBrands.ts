import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
const ManageBrands = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ManageBrands.url(options),
    method: 'get',
})

ManageBrands.definition = {
    methods: ["get","head"],
    url: '/admin/brands',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
ManageBrands.url = (options?: RouteQueryOptions) => {
    return ManageBrands.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
ManageBrands.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ManageBrands.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
ManageBrands.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ManageBrands.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
const ManageBrandsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageBrands.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
ManageBrandsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageBrands.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
ManageBrandsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageBrands.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

ManageBrands.form = ManageBrandsForm

export default ManageBrands