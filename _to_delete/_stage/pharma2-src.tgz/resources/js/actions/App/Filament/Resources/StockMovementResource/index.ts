import Pages from './Pages'

const StockMovementResource = {
    Pages: Object.assign(Pages, Pages),
}

export default StockMovementResource