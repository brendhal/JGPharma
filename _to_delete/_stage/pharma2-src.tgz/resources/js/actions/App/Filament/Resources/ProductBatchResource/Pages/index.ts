import ManageProductBatches from './ManageProductBatches'

const Pages = {
    ManageProductBatches: Object.assign(ManageProductBatches, ManageProductBatches),
}

export default Pages