import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\SaleResource\Pages\ViewSale::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ViewSale.php:7
* @route '/admin/sales/{record}'
*/
const ViewSale = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewSale.url(args, options),
    method: 'get',
})

ViewSale.definition = {
    methods: ["get","head"],
    url: '/admin/sales/{record}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\SaleResource\Pages\ViewSale::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ViewSale.php:7
* @route '/admin/sales/{record}'
*/
ViewSale.url = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { record: args }
    }

    if (Array.isArray(args)) {
        args = {
            record: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        record: args.record,
    }

    return ViewSale.definition.url
            .replace('{record}', parsedArgs.record.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Filament\Resources\SaleResource\Pages\ViewSale::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ViewSale.php:7
* @route '/admin/sales/{record}'
*/
ViewSale.get = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewSale.url(args, options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\SaleResource\Pages\ViewSale::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ViewSale.php:7
* @route '/admin/sales/{record}'
*/
ViewSale.head = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewSale.url(args, options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\SaleResource\Pages\ViewSale::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ViewSale.php:7
* @route '/admin/sales/{record}'
*/
const ViewSaleForm = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ViewSale.url(args, options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\SaleResource\Pages\ViewSale::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ViewSale.php:7
* @route '/admin/sales/{record}'
*/
ViewSaleForm.get = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ViewSale.url(args, options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\SaleResource\Pages\ViewSale::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ViewSale.php:7
* @route '/admin/sales/{record}'
*/
ViewSaleForm.head = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ViewSale.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

ViewSale.form = ViewSaleForm

export default ViewSale