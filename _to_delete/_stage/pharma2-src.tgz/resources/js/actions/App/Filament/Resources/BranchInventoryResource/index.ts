import Pages from './Pages'

const BranchInventoryResource = {
    Pages: Object.assign(Pages, Pages),
}

export default BranchInventoryResource