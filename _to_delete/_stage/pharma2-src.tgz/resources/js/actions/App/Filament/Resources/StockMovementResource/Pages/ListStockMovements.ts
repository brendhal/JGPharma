import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\StockMovementResource\Pages\ListStockMovements::__invoke
* @see app/Filament/Resources/StockMovementResource/Pages/ListStockMovements.php:7
* @route '/admin/stock-movements'
*/
const ListStockMovements = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ListStockMovements.url(options),
    method: 'get',
})

ListStockMovements.definition = {
    methods: ["get","head"],
    url: '/admin/stock-movements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\StockMovementResource\Pages\ListStockMovements::__invoke
* @see app/Filament/Resources/StockMovementResource/Pages/ListStockMovements.php:7
* @route '/admin/stock-movements'
*/
ListStockMovements.url = (options?: RouteQueryOptions) => {
    return ListStockMovements.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\StockMovementResource\Pages\ListStockMovements::__invoke
* @see app/Filament/Resources/StockMovementResource/Pages/ListStockMovements.php:7
* @route '/admin/stock-movements'
*/
ListStockMovements.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ListStockMovements.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\StockMovementResource\Pages\ListStockMovements::__invoke
* @see app/Filament/Resources/StockMovementResource/Pages/ListStockMovements.php:7
* @route '/admin/stock-movements'
*/
ListStockMovements.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ListStockMovements.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\StockMovementResource\Pages\ListStockMovements::__invoke
* @see app/Filament/Resources/StockMovementResource/Pages/ListStockMovements.php:7
* @route '/admin/stock-movements'
*/
const ListStockMovementsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListStockMovements.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\StockMovementResource\Pages\ListStockMovements::__invoke
* @see app/Filament/Resources/StockMovementResource/Pages/ListStockMovements.php:7
* @route '/admin/stock-movements'
*/
ListStockMovementsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListStockMovements.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\StockMovementResource\Pages\ListStockMovements::__invoke
* @see app/Filament/Resources/StockMovementResource/Pages/ListStockMovements.php:7
* @route '/admin/stock-movements'
*/
ListStockMovementsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListStockMovements.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

ListStockMovements.form = ListStockMovementsForm

export default ListStockMovements