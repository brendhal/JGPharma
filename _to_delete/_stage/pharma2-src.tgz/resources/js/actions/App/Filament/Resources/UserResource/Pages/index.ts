import ManageUsers from './ManageUsers'

const Pages = {
    ManageUsers: Object.assign(ManageUsers, ManageUsers),
}

export default Pages