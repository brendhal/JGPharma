import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
const ManageProductBatches = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ManageProductBatches.url(options),
    method: 'get',
})

ManageProductBatches.definition = {
    methods: ["get","head"],
    url: '/admin/product-batches',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
ManageProductBatches.url = (options?: RouteQueryOptions) => {
    return ManageProductBatches.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
ManageProductBatches.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ManageProductBatches.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
ManageProductBatches.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ManageProductBatches.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
const ManageProductBatchesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageProductBatches.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
ManageProductBatchesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageProductBatches.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
ManageProductBatchesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageProductBatches.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

ManageProductBatches.form = ManageProductBatchesForm

export default ManageProductBatches