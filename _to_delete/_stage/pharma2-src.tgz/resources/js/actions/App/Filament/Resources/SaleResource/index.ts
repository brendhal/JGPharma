import Pages from './Pages'

const SaleResource = {
    Pages: Object.assign(Pages, Pages),
}

export default SaleResource