import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
const ManageSuppliers = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ManageSuppliers.url(options),
    method: 'get',
})

ManageSuppliers.definition = {
    methods: ["get","head"],
    url: '/admin/suppliers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
ManageSuppliers.url = (options?: RouteQueryOptions) => {
    return ManageSuppliers.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
ManageSuppliers.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ManageSuppliers.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
ManageSuppliers.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ManageSuppliers.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
const ManageSuppliersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageSuppliers.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
ManageSuppliersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageSuppliers.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
ManageSuppliersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageSuppliers.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

ManageSuppliers.form = ManageSuppliersForm

export default ManageSuppliers