import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\PurchaseResource\Pages\ListPurchases::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/ListPurchases.php:7
* @route '/admin/purchases'
*/
const ListPurchases = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ListPurchases.url(options),
    method: 'get',
})

ListPurchases.definition = {
    methods: ["get","head"],
    url: '/admin/purchases',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\PurchaseResource\Pages\ListPurchases::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/ListPurchases.php:7
* @route '/admin/purchases'
*/
ListPurchases.url = (options?: RouteQueryOptions) => {
    return ListPurchases.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\PurchaseResource\Pages\ListPurchases::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/ListPurchases.php:7
* @route '/admin/purchases'
*/
ListPurchases.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ListPurchases.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\PurchaseResource\Pages\ListPurchases::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/ListPurchases.php:7
* @route '/admin/purchases'
*/
ListPurchases.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ListPurchases.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\PurchaseResource\Pages\ListPurchases::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/ListPurchases.php:7
* @route '/admin/purchases'
*/
const ListPurchasesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListPurchases.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\PurchaseResource\Pages\ListPurchases::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/ListPurchases.php:7
* @route '/admin/purchases'
*/
ListPurchasesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListPurchases.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\PurchaseResource\Pages\ListPurchases::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/ListPurchases.php:7
* @route '/admin/purchases'
*/
ListPurchasesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListPurchases.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

ListPurchases.form = ListPurchasesForm

export default ListPurchases