import ListStockTransfers from './ListStockTransfers'
import CreateStockTransfer from './CreateStockTransfer'
import EditStockTransfer from './EditStockTransfer'

const Pages = {
    ListStockTransfers: Object.assign(ListStockTransfers, ListStockTransfers),
    CreateStockTransfer: Object.assign(CreateStockTransfer, CreateStockTransfer),
    EditStockTransfer: Object.assign(EditStockTransfer, EditStockTransfer),
}

export default Pages