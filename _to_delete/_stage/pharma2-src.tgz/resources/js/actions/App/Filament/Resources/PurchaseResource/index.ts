import Pages from './Pages'

const PurchaseResource = {
    Pages: Object.assign(Pages, Pages),
}

export default PurchaseResource