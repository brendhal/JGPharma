import Pages from './Pages'

const StockTransferResource = {
    Pages: Object.assign(Pages, Pages),
}

export default StockTransferResource