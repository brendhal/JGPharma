import Dashboard from './Dashboard'
import PointOfSale from './PointOfSale'
import Reports from './Reports'

const Pages = {
    Dashboard: Object.assign(Dashboard, Dashboard),
    PointOfSale: Object.assign(PointOfSale, PointOfSale),
    Reports: Object.assign(Reports, Reports),
}

export default Pages