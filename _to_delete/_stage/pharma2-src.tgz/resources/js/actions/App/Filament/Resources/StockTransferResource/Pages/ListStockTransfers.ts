import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\StockTransferResource\Pages\ListStockTransfers::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/ListStockTransfers.php:7
* @route '/admin/stock-transfers'
*/
const ListStockTransfers = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ListStockTransfers.url(options),
    method: 'get',
})

ListStockTransfers.definition = {
    methods: ["get","head"],
    url: '/admin/stock-transfers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\ListStockTransfers::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/ListStockTransfers.php:7
* @route '/admin/stock-transfers'
*/
ListStockTransfers.url = (options?: RouteQueryOptions) => {
    return ListStockTransfers.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\ListStockTransfers::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/ListStockTransfers.php:7
* @route '/admin/stock-transfers'
*/
ListStockTransfers.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ListStockTransfers.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\ListStockTransfers::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/ListStockTransfers.php:7
* @route '/admin/stock-transfers'
*/
ListStockTransfers.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ListStockTransfers.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\ListStockTransfers::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/ListStockTransfers.php:7
* @route '/admin/stock-transfers'
*/
const ListStockTransfersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListStockTransfers.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\ListStockTransfers::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/ListStockTransfers.php:7
* @route '/admin/stock-transfers'
*/
ListStockTransfersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListStockTransfers.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\ListStockTransfers::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/ListStockTransfers.php:7
* @route '/admin/stock-transfers'
*/
ListStockTransfersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListStockTransfers.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

ListStockTransfers.form = ListStockTransfersForm

export default ListStockTransfers