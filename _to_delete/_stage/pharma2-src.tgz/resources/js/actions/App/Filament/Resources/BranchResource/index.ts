import Pages from './Pages'

const BranchResource = {
    Pages: Object.assign(Pages, Pages),
}

export default BranchResource