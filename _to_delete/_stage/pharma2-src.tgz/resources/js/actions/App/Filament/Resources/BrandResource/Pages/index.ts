import ManageBrands from './ManageBrands'

const Pages = {
    ManageBrands: Object.assign(ManageBrands, ManageBrands),
}

export default Pages