import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
const PointOfSale = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PointOfSale.url(options),
    method: 'get',
})

PointOfSale.definition = {
    methods: ["get","head"],
    url: '/admin/point-of-sale',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
PointOfSale.url = (options?: RouteQueryOptions) => {
    return PointOfSale.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
PointOfSale.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PointOfSale.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
PointOfSale.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: PointOfSale.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
const PointOfSaleForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: PointOfSale.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
PointOfSaleForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: PointOfSale.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
PointOfSaleForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: PointOfSale.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

PointOfSale.form = PointOfSaleForm

export default PointOfSale