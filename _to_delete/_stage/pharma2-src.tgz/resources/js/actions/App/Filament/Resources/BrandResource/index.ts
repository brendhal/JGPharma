import Pages from './Pages'

const BrandResource = {
    Pages: Object.assign(Pages, Pages),
}

export default BrandResource