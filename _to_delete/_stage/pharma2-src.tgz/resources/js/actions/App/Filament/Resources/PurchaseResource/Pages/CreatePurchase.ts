import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\PurchaseResource\Pages\CreatePurchase::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/CreatePurchase.php:7
* @route '/admin/purchases/create'
*/
const CreatePurchase = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: CreatePurchase.url(options),
    method: 'get',
})

CreatePurchase.definition = {
    methods: ["get","head"],
    url: '/admin/purchases/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\PurchaseResource\Pages\CreatePurchase::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/CreatePurchase.php:7
* @route '/admin/purchases/create'
*/
CreatePurchase.url = (options?: RouteQueryOptions) => {
    return CreatePurchase.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\PurchaseResource\Pages\CreatePurchase::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/CreatePurchase.php:7
* @route '/admin/purchases/create'
*/
CreatePurchase.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: CreatePurchase.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\PurchaseResource\Pages\CreatePurchase::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/CreatePurchase.php:7
* @route '/admin/purchases/create'
*/
CreatePurchase.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: CreatePurchase.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\PurchaseResource\Pages\CreatePurchase::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/CreatePurchase.php:7
* @route '/admin/purchases/create'
*/
const CreatePurchaseForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: CreatePurchase.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\PurchaseResource\Pages\CreatePurchase::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/CreatePurchase.php:7
* @route '/admin/purchases/create'
*/
CreatePurchaseForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: CreatePurchase.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\PurchaseResource\Pages\CreatePurchase::__invoke
* @see app/Filament/Resources/PurchaseResource/Pages/CreatePurchase.php:7
* @route '/admin/purchases/create'
*/
CreatePurchaseForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: CreatePurchase.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

CreatePurchase.form = CreatePurchaseForm

export default CreatePurchase