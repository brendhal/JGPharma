import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\StockTransferResource\Pages\EditStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/EditStockTransfer.php:7
* @route '/admin/stock-transfers/{record}/edit'
*/
const EditStockTransfer = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: EditStockTransfer.url(args, options),
    method: 'get',
})

EditStockTransfer.definition = {
    methods: ["get","head"],
    url: '/admin/stock-transfers/{record}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\EditStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/EditStockTransfer.php:7
* @route '/admin/stock-transfers/{record}/edit'
*/
EditStockTransfer.url = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { record: args }
    }

    if (Array.isArray(args)) {
        args = {
            record: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        record: args.record,
    }

    return EditStockTransfer.definition.url
            .replace('{record}', parsedArgs.record.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\EditStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/EditStockTransfer.php:7
* @route '/admin/stock-transfers/{record}/edit'
*/
EditStockTransfer.get = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: EditStockTransfer.url(args, options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\EditStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/EditStockTransfer.php:7
* @route '/admin/stock-transfers/{record}/edit'
*/
EditStockTransfer.head = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: EditStockTransfer.url(args, options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\EditStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/EditStockTransfer.php:7
* @route '/admin/stock-transfers/{record}/edit'
*/
const EditStockTransferForm = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: EditStockTransfer.url(args, options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\EditStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/EditStockTransfer.php:7
* @route '/admin/stock-transfers/{record}/edit'
*/
EditStockTransferForm.get = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: EditStockTransfer.url(args, options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\StockTransferResource\Pages\EditStockTransfer::__invoke
* @see app/Filament/Resources/StockTransferResource/Pages/EditStockTransfer.php:7
* @route '/admin/stock-transfers/{record}/edit'
*/
EditStockTransferForm.head = (args: { record: string | number } | [record: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: EditStockTransfer.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

EditStockTransfer.form = EditStockTransferForm

export default EditStockTransfer