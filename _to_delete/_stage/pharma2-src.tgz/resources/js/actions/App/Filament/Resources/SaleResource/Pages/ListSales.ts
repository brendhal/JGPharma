import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\SaleResource\Pages\ListSales::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ListSales.php:7
* @route '/admin/sales'
*/
const ListSales = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ListSales.url(options),
    method: 'get',
})

ListSales.definition = {
    methods: ["get","head"],
    url: '/admin/sales',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\SaleResource\Pages\ListSales::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ListSales.php:7
* @route '/admin/sales'
*/
ListSales.url = (options?: RouteQueryOptions) => {
    return ListSales.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\SaleResource\Pages\ListSales::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ListSales.php:7
* @route '/admin/sales'
*/
ListSales.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ListSales.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\SaleResource\Pages\ListSales::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ListSales.php:7
* @route '/admin/sales'
*/
ListSales.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ListSales.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\SaleResource\Pages\ListSales::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ListSales.php:7
* @route '/admin/sales'
*/
const ListSalesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListSales.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\SaleResource\Pages\ListSales::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ListSales.php:7
* @route '/admin/sales'
*/
ListSalesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListSales.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\SaleResource\Pages\ListSales::__invoke
* @see app/Filament/Resources/SaleResource/Pages/ListSales.php:7
* @route '/admin/sales'
*/
ListSalesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListSales.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

ListSales.form = ListSalesForm

export default ListSales