import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\UserResource\Pages\ManageUsers::__invoke
* @see app/Filament/Resources/UserResource/Pages/ManageUsers.php:7
* @route '/admin/users'
*/
const ManageUsers = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ManageUsers.url(options),
    method: 'get',
})

ManageUsers.definition = {
    methods: ["get","head"],
    url: '/admin/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\UserResource\Pages\ManageUsers::__invoke
* @see app/Filament/Resources/UserResource/Pages/ManageUsers.php:7
* @route '/admin/users'
*/
ManageUsers.url = (options?: RouteQueryOptions) => {
    return ManageUsers.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\UserResource\Pages\ManageUsers::__invoke
* @see app/Filament/Resources/UserResource/Pages/ManageUsers.php:7
* @route '/admin/users'
*/
ManageUsers.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ManageUsers.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\UserResource\Pages\ManageUsers::__invoke
* @see app/Filament/Resources/UserResource/Pages/ManageUsers.php:7
* @route '/admin/users'
*/
ManageUsers.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ManageUsers.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\UserResource\Pages\ManageUsers::__invoke
* @see app/Filament/Resources/UserResource/Pages/ManageUsers.php:7
* @route '/admin/users'
*/
const ManageUsersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageUsers.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\UserResource\Pages\ManageUsers::__invoke
* @see app/Filament/Resources/UserResource/Pages/ManageUsers.php:7
* @route '/admin/users'
*/
ManageUsersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageUsers.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\UserResource\Pages\ManageUsers::__invoke
* @see app/Filament/Resources/UserResource/Pages/ManageUsers.php:7
* @route '/admin/users'
*/
ManageUsersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageUsers.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

ManageUsers.form = ManageUsersForm

export default ManageUsers