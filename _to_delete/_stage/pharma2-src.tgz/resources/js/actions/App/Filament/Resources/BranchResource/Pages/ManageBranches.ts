import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
const ManageBranches = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ManageBranches.url(options),
    method: 'get',
})

ManageBranches.definition = {
    methods: ["get","head"],
    url: '/admin/branches',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
ManageBranches.url = (options?: RouteQueryOptions) => {
    return ManageBranches.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
ManageBranches.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ManageBranches.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
ManageBranches.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ManageBranches.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
const ManageBranchesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageBranches.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
ManageBranchesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageBranches.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
ManageBranchesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ManageBranches.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

ManageBranches.form = ManageBranchesForm

export default ManageBranches