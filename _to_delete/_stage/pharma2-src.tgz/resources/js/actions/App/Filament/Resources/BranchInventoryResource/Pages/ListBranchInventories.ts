import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
const ListBranchInventories = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ListBranchInventories.url(options),
    method: 'get',
})

ListBranchInventories.definition = {
    methods: ["get","head"],
    url: '/admin/branch-inventories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
ListBranchInventories.url = (options?: RouteQueryOptions) => {
    return ListBranchInventories.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
ListBranchInventories.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ListBranchInventories.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
ListBranchInventories.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ListBranchInventories.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
const ListBranchInventoriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListBranchInventories.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
ListBranchInventoriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListBranchInventories.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
ListBranchInventoriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ListBranchInventories.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

ListBranchInventories.form = ListBranchInventoriesForm

export default ListBranchInventories