import ListBranchInventories from './ListBranchInventories'

const Pages = {
    ListBranchInventories: Object.assign(ListBranchInventories, ListBranchInventories),
}

export default Pages