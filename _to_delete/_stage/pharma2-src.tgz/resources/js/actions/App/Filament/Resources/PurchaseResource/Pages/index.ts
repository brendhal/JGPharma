import ListPurchases from './ListPurchases'
import CreatePurchase from './CreatePurchase'
import EditPurchase from './EditPurchase'

const Pages = {
    ListPurchases: Object.assign(ListPurchases, ListPurchases),
    CreatePurchase: Object.assign(CreatePurchase, CreatePurchase),
    EditPurchase: Object.assign(EditPurchase, EditPurchase),
}

export default Pages