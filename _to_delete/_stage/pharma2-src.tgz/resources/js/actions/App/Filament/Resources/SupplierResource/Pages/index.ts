import ManageSuppliers from './ManageSuppliers'

const Pages = {
    ManageSuppliers: Object.assign(ManageSuppliers, ManageSuppliers),
}

export default Pages