import ListStockMovements from './ListStockMovements'

const Pages = {
    ListStockMovements: Object.assign(ListStockMovements, ListStockMovements),
}

export default Pages