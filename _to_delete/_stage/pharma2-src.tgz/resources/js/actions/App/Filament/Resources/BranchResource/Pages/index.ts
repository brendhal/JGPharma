import ManageBranches from './ManageBranches'

const Pages = {
    ManageBranches: Object.assign(ManageBranches, ManageBranches),
}

export default Pages