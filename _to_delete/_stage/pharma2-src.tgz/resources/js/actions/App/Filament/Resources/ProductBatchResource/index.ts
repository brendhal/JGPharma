import Pages from './Pages'

const ProductBatchResource = {
    Pages: Object.assign(Pages, Pages),
}

export default ProductBatchResource