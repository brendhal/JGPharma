import BranchInventoryResource from './BranchInventoryResource'
import BranchResource from './BranchResource'
import BrandResource from './BrandResource'
import CategoryResource from './CategoryResource'
import ProductBatchResource from './ProductBatchResource'
import ProductResource from './ProductResource'
import PurchaseResource from './PurchaseResource'
import SaleResource from './SaleResource'
import StockMovementResource from './StockMovementResource'
import StockTransferResource from './StockTransferResource'
import SupplierResource from './SupplierResource'
import UserResource from './UserResource'

const Resources = {
    BranchInventoryResource: Object.assign(BranchInventoryResource, BranchInventoryResource),
    BranchResource: Object.assign(BranchResource, BranchResource),
    BrandResource: Object.assign(BrandResource, BrandResource),
    CategoryResource: Object.assign(CategoryResource, CategoryResource),
    ProductBatchResource: Object.assign(ProductBatchResource, ProductBatchResource),
    ProductResource: Object.assign(ProductResource, ProductResource),
    PurchaseResource: Object.assign(PurchaseResource, PurchaseResource),
    SaleResource: Object.assign(SaleResource, SaleResource),
    StockMovementResource: Object.assign(StockMovementResource, StockMovementResource),
    StockTransferResource: Object.assign(StockTransferResource, StockTransferResource),
    SupplierResource: Object.assign(SupplierResource, SupplierResource),
    UserResource: Object.assign(UserResource, UserResource),
}

export default Resources