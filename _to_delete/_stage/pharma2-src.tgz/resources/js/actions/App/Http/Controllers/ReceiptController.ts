import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReceiptController::__invoke
* @see app/Http/Controllers/ReceiptController.php:11
* @route '/receipts/{sale}'
*/
const ReceiptController = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ReceiptController.url(args, options),
    method: 'get',
})

ReceiptController.definition = {
    methods: ["get","head"],
    url: '/receipts/{sale}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReceiptController::__invoke
* @see app/Http/Controllers/ReceiptController.php:11
* @route '/receipts/{sale}'
*/
ReceiptController.url = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sale: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { sale: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            sale: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        sale: typeof args.sale === 'object'
        ? args.sale.id
        : args.sale,
    }

    return ReceiptController.definition.url
            .replace('{sale}', parsedArgs.sale.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReceiptController::__invoke
* @see app/Http/Controllers/ReceiptController.php:11
* @route '/receipts/{sale}'
*/
ReceiptController.get = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ReceiptController.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReceiptController::__invoke
* @see app/Http/Controllers/ReceiptController.php:11
* @route '/receipts/{sale}'
*/
ReceiptController.head = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ReceiptController.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReceiptController::__invoke
* @see app/Http/Controllers/ReceiptController.php:11
* @route '/receipts/{sale}'
*/
const ReceiptControllerForm = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ReceiptController.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReceiptController::__invoke
* @see app/Http/Controllers/ReceiptController.php:11
* @route '/receipts/{sale}'
*/
ReceiptControllerForm.get = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ReceiptController.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReceiptController::__invoke
* @see app/Http/Controllers/ReceiptController.php:11
* @route '/receipts/{sale}'
*/
ReceiptControllerForm.head = (args: { sale: number | { id: number } } | [sale: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: ReceiptController.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

ReceiptController.form = ReceiptControllerForm

export default ReceiptController