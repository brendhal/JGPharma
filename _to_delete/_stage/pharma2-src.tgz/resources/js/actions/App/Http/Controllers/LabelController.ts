import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\LabelController::sheet
* @see app/Http/Controllers/LabelController.php:14
* @route '/labels/{product}'
*/
export const sheet = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sheet.url(args, options),
    method: 'get',
})

sheet.definition = {
    methods: ["get","head"],
    url: '/labels/{product}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LabelController::sheet
* @see app/Http/Controllers/LabelController.php:14
* @route '/labels/{product}'
*/
sheet.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return sheet.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LabelController::sheet
* @see app/Http/Controllers/LabelController.php:14
* @route '/labels/{product}'
*/
sheet.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sheet.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LabelController::sheet
* @see app/Http/Controllers/LabelController.php:14
* @route '/labels/{product}'
*/
sheet.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sheet.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LabelController::sheet
* @see app/Http/Controllers/LabelController.php:14
* @route '/labels/{product}'
*/
const sheetForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sheet.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LabelController::sheet
* @see app/Http/Controllers/LabelController.php:14
* @route '/labels/{product}'
*/
sheetForm.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sheet.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LabelController::sheet
* @see app/Http/Controllers/LabelController.php:14
* @route '/labels/{product}'
*/
sheetForm.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: sheet.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

sheet.form = sheetForm

/**
* @see \App\Http\Controllers\LabelController::qr
* @see app/Http/Controllers/LabelController.php:27
* @route '/labels/{product}/qr'
*/
export const qr = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qr.url(args, options),
    method: 'get',
})

qr.definition = {
    methods: ["get","head"],
    url: '/labels/{product}/qr',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LabelController::qr
* @see app/Http/Controllers/LabelController.php:27
* @route '/labels/{product}/qr'
*/
qr.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { product: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            product: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        product: typeof args.product === 'object'
        ? args.product.id
        : args.product,
    }

    return qr.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LabelController::qr
* @see app/Http/Controllers/LabelController.php:27
* @route '/labels/{product}/qr'
*/
qr.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qr.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LabelController::qr
* @see app/Http/Controllers/LabelController.php:27
* @route '/labels/{product}/qr'
*/
qr.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: qr.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\LabelController::qr
* @see app/Http/Controllers/LabelController.php:27
* @route '/labels/{product}/qr'
*/
const qrForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qr.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LabelController::qr
* @see app/Http/Controllers/LabelController.php:27
* @route '/labels/{product}/qr'
*/
qrForm.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qr.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\LabelController::qr
* @see app/Http/Controllers/LabelController.php:27
* @route '/labels/{product}/qr'
*/
qrForm.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qr.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

qr.form = qrForm

const LabelController = { sheet, qr }

export default LabelController