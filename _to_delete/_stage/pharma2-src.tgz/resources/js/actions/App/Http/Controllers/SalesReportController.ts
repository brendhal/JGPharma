import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
const SalesReportController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SalesReportController.url(options),
    method: 'get',
})

SalesReportController.definition = {
    methods: ["get","head"],
    url: '/sales-report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
SalesReportController.url = (options?: RouteQueryOptions) => {
    return SalesReportController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
SalesReportController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: SalesReportController.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
SalesReportController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: SalesReportController.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
const SalesReportControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: SalesReportController.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
SalesReportControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: SalesReportController.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
SalesReportControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: SalesReportController.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

SalesReportController.form = SalesReportControllerForm

export default SalesReportController