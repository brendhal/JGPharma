import LabelController from './LabelController'
import ReceiptController from './ReceiptController'
import SalesReportController from './SalesReportController'
import Settings from './Settings'

const Controllers = {
    LabelController: Object.assign(LabelController, LabelController),
    ReceiptController: Object.assign(ReceiptController, ReceiptController),
    SalesReportController: Object.assign(SalesReportController, SalesReportController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers