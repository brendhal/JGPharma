import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/suppliers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\SupplierResource\Pages\ManageSuppliers::__invoke
* @see app/Filament/Resources/SupplierResource/Pages/ManageSuppliers.php:7
* @route '/admin/suppliers'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const suppliers = {
    index: Object.assign(index, index),
}

export default suppliers