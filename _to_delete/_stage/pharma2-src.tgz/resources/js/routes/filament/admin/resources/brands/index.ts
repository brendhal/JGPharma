import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/brands',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BrandResource\Pages\ManageBrands::__invoke
* @see app/Filament/Resources/BrandResource/Pages/ManageBrands.php:7
* @route '/admin/brands'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const brands = {
    index: Object.assign(index, index),
}

export default brands