import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Filament\Pages\Dashboard::__invoke
* @see app/Filament/Pages/Dashboard.php:7
* @route '/admin'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/admin',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Pages\Dashboard::__invoke
* @see app/Filament/Pages/Dashboard.php:7
* @route '/admin'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Pages\Dashboard::__invoke
* @see app/Filament/Pages/Dashboard.php:7
* @route '/admin'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Pages\Dashboard::__invoke
* @see app/Filament/Pages/Dashboard.php:7
* @route '/admin'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Pages\Dashboard::__invoke
* @see app/Filament/Pages/Dashboard.php:7
* @route '/admin'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Pages\Dashboard::__invoke
* @see app/Filament/Pages/Dashboard.php:7
* @route '/admin'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Pages\Dashboard::__invoke
* @see app/Filament/Pages/Dashboard.php:7
* @route '/admin'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
export const pointOfSale = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pointOfSale.url(options),
    method: 'get',
})

pointOfSale.definition = {
    methods: ["get","head"],
    url: '/admin/point-of-sale',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
pointOfSale.url = (options?: RouteQueryOptions) => {
    return pointOfSale.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
pointOfSale.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pointOfSale.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
pointOfSale.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pointOfSale.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
const pointOfSaleForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pointOfSale.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
pointOfSaleForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pointOfSale.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Pages\PointOfSale::__invoke
* @see app/Filament/Pages/PointOfSale.php:7
* @route '/admin/point-of-sale'
*/
pointOfSaleForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pointOfSale.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

pointOfSale.form = pointOfSaleForm

/**
* @see \App\Filament\Pages\Reports::__invoke
* @see app/Filament/Pages/Reports.php:7
* @route '/admin/reports'
*/
export const reports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

reports.definition = {
    methods: ["get","head"],
    url: '/admin/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Pages\Reports::__invoke
* @see app/Filament/Pages/Reports.php:7
* @route '/admin/reports'
*/
reports.url = (options?: RouteQueryOptions) => {
    return reports.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Pages\Reports::__invoke
* @see app/Filament/Pages/Reports.php:7
* @route '/admin/reports'
*/
reports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reports.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Pages\Reports::__invoke
* @see app/Filament/Pages/Reports.php:7
* @route '/admin/reports'
*/
reports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reports.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Pages\Reports::__invoke
* @see app/Filament/Pages/Reports.php:7
* @route '/admin/reports'
*/
const reportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Pages\Reports::__invoke
* @see app/Filament/Pages/Reports.php:7
* @route '/admin/reports'
*/
reportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Pages\Reports::__invoke
* @see app/Filament/Pages/Reports.php:7
* @route '/admin/reports'
*/
reportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: reports.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

reports.form = reportsForm

const pages = {
    dashboard: Object.assign(dashboard, dashboard),
    pointOfSale: Object.assign(pointOfSale, pointOfSale),
    reports: Object.assign(reports, reports),
}

export default pages