import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/product-batches',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\ProductBatchResource\Pages\ManageProductBatches::__invoke
* @see app/Filament/Resources/ProductBatchResource/Pages/ManageProductBatches.php:7
* @route '/admin/product-batches'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const productBatches = {
    index: Object.assign(index, index),
}

export default productBatches