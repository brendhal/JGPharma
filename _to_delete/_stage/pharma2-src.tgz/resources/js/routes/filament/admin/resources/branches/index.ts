import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/branches',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BranchResource\Pages\ManageBranches::__invoke
* @see app/Filament/Resources/BranchResource/Pages/ManageBranches.php:7
* @route '/admin/branches'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const branches = {
    index: Object.assign(index, index),
}

export default branches