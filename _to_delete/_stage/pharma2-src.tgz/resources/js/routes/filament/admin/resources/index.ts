import branchInventories from './branch-inventories'
import branches from './branches'
import brands from './brands'
import categories from './categories'
import productBatches from './product-batches'
import products from './products'
import purchases from './purchases'
import sales from './sales'
import stockMovements from './stock-movements'
import stockTransfers from './stock-transfers'
import suppliers from './suppliers'
import users from './users'

const resources = {
    branchInventories: Object.assign(branchInventories, branchInventories),
    branches: Object.assign(branches, branches),
    brands: Object.assign(brands, brands),
    categories: Object.assign(categories, categories),
    productBatches: Object.assign(productBatches, productBatches),
    products: Object.assign(products, products),
    purchases: Object.assign(purchases, purchases),
    sales: Object.assign(sales, sales),
    stockMovements: Object.assign(stockMovements, stockMovements),
    stockTransfers: Object.assign(stockTransfers, stockTransfers),
    suppliers: Object.assign(suppliers, suppliers),
    users: Object.assign(users, users),
}

export default resources