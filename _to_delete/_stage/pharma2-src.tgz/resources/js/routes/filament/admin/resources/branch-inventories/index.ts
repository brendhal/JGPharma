import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/branch-inventories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\BranchInventoryResource\Pages\ListBranchInventories::__invoke
* @see app/Filament/Resources/BranchInventoryResource/Pages/ListBranchInventories.php:7
* @route '/admin/branch-inventories'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const branchInventories = {
    index: Object.assign(index, index),
}

export default branchInventories