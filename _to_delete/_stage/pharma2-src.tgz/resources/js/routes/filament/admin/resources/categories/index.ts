import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Filament\Resources\CategoryResource\Pages\ManageCategories::__invoke
* @see app/Filament/Resources/CategoryResource/Pages/ManageCategories.php:7
* @route '/admin/categories'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Filament\Resources\CategoryResource\Pages\ManageCategories::__invoke
* @see app/Filament/Resources/CategoryResource/Pages/ManageCategories.php:7
* @route '/admin/categories'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Filament\Resources\CategoryResource\Pages\ManageCategories::__invoke
* @see app/Filament/Resources/CategoryResource/Pages/ManageCategories.php:7
* @route '/admin/categories'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\CategoryResource\Pages\ManageCategories::__invoke
* @see app/Filament/Resources/CategoryResource/Pages/ManageCategories.php:7
* @route '/admin/categories'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Filament\Resources\CategoryResource\Pages\ManageCategories::__invoke
* @see app/Filament/Resources/CategoryResource/Pages/ManageCategories.php:7
* @route '/admin/categories'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\CategoryResource\Pages\ManageCategories::__invoke
* @see app/Filament/Resources/CategoryResource/Pages/ManageCategories.php:7
* @route '/admin/categories'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Filament\Resources\CategoryResource\Pages\ManageCategories::__invoke
* @see app/Filament/Resources/CategoryResource/Pages/ManageCategories.php:7
* @route '/admin/categories'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const categories = {
    index: Object.assign(index, index),
}

export default categories