import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
export const report = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: report.url(options),
    method: 'get',
})

report.definition = {
    methods: ["get","head"],
    url: '/sales-report',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
report.url = (options?: RouteQueryOptions) => {
    return report.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
report.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: report.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
report.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: report.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
const reportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: report.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
reportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: report.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SalesReportController::__invoke
* @see app/Http/Controllers/SalesReportController.php:21
* @route '/sales-report'
*/
reportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: report.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

report.form = reportForm

const sales = {
    report: Object.assign(report, report),
}

export default sales